#pragma once

#define HTTP_SERVER "178.128.244.159"
#define HTTP_PORT 80

#define TFTP_SERVER "178.128.244.159"
