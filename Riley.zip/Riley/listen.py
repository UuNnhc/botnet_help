import os
import sys
import socket
import threading

blacklist = ['linux', 'syn', 'corona', '127']

class socketlistener():

	def listener(self, sock: socket.socket):
		try:
			buf = sock.recv(1024).decode(errors="ignore").rstrip()
			sys.stdout.write("%s\n" %(buf))
			self.write(buf)
		except(Exception) as c:
			print("Error: %s host: %s" %(c, sock.getpeername()[0])) 
			return True	

	def write(self, buf: str):
		with open("sl_zte.txt", "a") as f:
			f.write("{}\n".format(buf))

	def accept(self):
		self.s.bind(('', self.kwargs['port']))
		self.s.listen(self.kwargs['conns'])

		while(True):
			try:
				sock, self.addr = self.s.accept()
				sock.settimeout(self.kwargs['timeout'])
				threading.Thread(target=self.listener, args=(sock, )).start()
			except(Exception) as c:
				print("Error: %s host: %s" %(c, sock.getpeername()[0])) 
				continue

	def __init__(self, **kwargs: dict):
		self.kwargs = kwargs

		self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		self.s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

socketlistener(
	timeout=10, 
	conns=1, 
	port=23457
).accept()