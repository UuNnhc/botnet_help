#pragma once

#define PROTO_DNS_QTYPE_TXT     16
#define PROTO_DNS_QCLASS_IP     1

struct dnshdr {
    uint16_t id, opts, qdcount, ancount, nscount, arcount;
};

struct dns_question {
    uint16_t qtype, qclass;
};

struct dns_resource {
    uint16_t type, _class;
    uint32_t ttl;
    uint16_t data_len;
} __attribute__((packed));

void resolv_grab_chain(char *, uint32_t *, uint16_t *);