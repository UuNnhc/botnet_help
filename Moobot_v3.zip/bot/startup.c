#define _GNU_SOURCE

#include <stdint.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/stat.h>

int startup_rclocal()
{
	
	return 1;
}
