#pragma once

int startup_rclocal();
