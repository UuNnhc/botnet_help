#pragma once

#define MUTEX_LEN			21

char *mutex_new_instance();
