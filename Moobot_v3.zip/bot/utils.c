#define _GNU_SOURCE

#include <stddef.h>
#include <errno.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#include "utils.h"

size_t utils_strlen(const char *str)
{
	register const char *s;
	for (s = str; *s; ++s);
	return(s - str);
}

void utils_memset(void *buf, int set, int len)
{
    char *zero = buf;
    while (len--)
        *zero++ = set;
}

void utils_memcpy(void *dst, void *src, int len)
{
    char *r_dst = (char *)dst;
    char *r_src = (char *)src;
    while (len--)
        *r_dst++ = *r_src++;
}

uint32_t utils_local_addr(void)
{
    int fd;
    struct sockaddr_in addr;
    socklen_t addr_len = sizeof (addr);

    errno = 0;
    if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
        return 0;

    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INET_ADDR(1,1,1,1);
    addr.sin_port = htons(53);

    connect(fd, (struct sockaddr *)&addr, sizeof (struct sockaddr_in));

    getsockname(fd, (struct sockaddr *)&addr, &addr_len);
    close(fd);
    return addr.sin_addr.s_addr;
}
