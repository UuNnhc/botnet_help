#pragma once

#include <stddef.h>

#define TCP_MAX_SIZE		2048
#define UDP_MAX_SIZE		1500
#define ICMP_STATIC_SIZE	20
#define SYN_MAX_SIZE		1400

struct pseudo_header 
{
	u_int32_t source_address;
	u_int32_t dest_address;
	u_int8_t placeholder;
	u_int8_t protocol;
	u_int16_t tcp_length;
};

void methods_tcp(uint32_t, char *, int);
void methods_udp(uint32_t, char *, int);
void methods_icmp(uint32_t, char *, int);
void methods_syn(uint32_t, char *, int);
