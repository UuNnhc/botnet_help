#pragma once

#include <stddef.h>

void tor_deshift_key(char *, int);
int tor_setup_fd(int, char *, int);
