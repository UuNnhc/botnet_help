#pragma once

#include <stddef.h>

#define INET_ADDR(o1,o2,o3,o4) (htonl((o1 << 24) | (o2 << 16) | (o3 << 8) | (o4 << 0)))

uint32_t local_addr;

size_t utils_strlen(const char *);
void utils_memset(void *, int, int);
void utils_memcpy(void *, void *, int);
uint32_t utils_local_addr(void);
