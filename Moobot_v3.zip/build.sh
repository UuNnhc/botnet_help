#!/bin/sh

compiler_dir="/home/me/Desktop/compilers/"
compiler_flags=""

rm -rf bins
mkdir bins

${compiler_dir}i586/bin/i586-gcc bot/*.c ${compiler_flags} -w -std=c99 -static -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o bins/i586
${compiler_dir}i586/bin/i586-strip bins/i586 -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
${compiler_dir}armv4l/bin/armv4l-gcc bot/*.c ${compiler_flags} -w -std=c99 -static -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o bins/armv4l
${compiler_dir}armv4l/bin/armv4l-strip bins/armv4l -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
${compiler_dir}armv7l/bin/armv7l-gcc bot/*.c ${compiler_flags} -w -std=c99 -static -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o bins/armv7l
${compiler_dir}armv7l/bin/armv7l-strip bins/armv7l -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
${compiler_dir}mips/bin/mips-gcc bot/*.c ${compiler_flags} -w -std=c99 -static -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o bins/mips
${compiler_dir}mips/bin/mips-strip bins/mips -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
${compiler_dir}mipsel/bin/mipsel-gcc bot/*.c ${compiler_flags} -w -std=c99 -static -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o bins/mipsel
${compiler_dir}mipsel/bin/mipsel-strip bins/mipsel -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
