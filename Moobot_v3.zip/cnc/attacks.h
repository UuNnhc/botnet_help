#pragma once

#include <stdint.h>

#define METHOD_TCP			1
#define METHOD_UDP			2
#define METHOD_ICMP			3
#define METHOD_SYN			4
#define METHOD_NULL			99

#define OPT_PORT			1
#define OPT_LEN				2
#define OPT_PAYLOAD			3
#define OPT_PACKETS			4
#define OPT_PPS				5
#define OPT_NOBIND			6
#define OPT_NETMASK			7
#define OPT_MULTISRC		8
#define OPT_RANDBITS		9

#define TYPE_UINT8			1
#define TYPE_UINT16			2
#define TYPE_UINT32			3
#define TYPE_STRING			4
#define TYPE_NULL			99

#define MAX_OPTS			15

struct attack_option_t {
	char *name, *desc;
	uint8_t id, type;
};

struct attack_method_t {
	char *name;
	uint8_t id, opts_len;
	uint8_t options[MAX_OPTS];
};

int attacks_contains_option(uint8_t, uint8_t *);
struct attack_option_t attacks_get_option(char *);
struct attack_option_t attacks_get_option_by_id(int);
struct attack_option_t *attacks_grab_options(int *);
struct attack_method_t *attacks_grab_methods(int *);
struct attack_method_t attacks_get_method(char *);
char *attacks_command_parse(uint8_t, char *, int *);
void attacks_options_init(void);
void attacks_methods_init(void);
