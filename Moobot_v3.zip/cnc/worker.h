#pragma once

#define WORKER_PORT		28131
#define WORKER_BIND		"0.0.0.0"

#define WORKER_MAX		999999

struct bot_info_t {
	int fd;
	char name[64];
	uint8_t name_len;
	uint32_t ping;
} bot_info[WORKER_MAX];

void worker_init(void);