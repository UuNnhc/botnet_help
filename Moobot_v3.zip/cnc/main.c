#define _GNU_SOURCE

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

#include "attacks.h"
#include "worker.h"
#include "admin.h"

int main()
{
	attacks_options_init();
	attacks_methods_init();
		
	admin_init();
	worker_init();

	while (1)
	{
		sleep(1);
	}
}
