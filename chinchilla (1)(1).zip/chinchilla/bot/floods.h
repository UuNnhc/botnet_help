void attack_parse_floods(char *buffer);

void attack_tcpraw_flood(char *target, int port, int timer, int data_len);
void attack_udp_flood(char *target, int port, int timer, int data_len);
