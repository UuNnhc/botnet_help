#pragma once

#define key 2

#define PROC 0
#define EXEC_MSG 1

#define MAX_TABLES 2

struct enc_table {
	int status;
	char value[100];
}

struct enc_table enc[MAX_TABLES];

void crypt_enc(char *string);
void crypt_add_val(int index, char *string);
void crypt_unlock_val(int index);
void crypt_lock_val(int index);
void xor_init(void);

