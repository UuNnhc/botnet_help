#include <stdio.h>
#include <stdlib.h>

#define key 2

void crypt_enc(char *string)
{
	int i;

	char enc_buf[strlen(string)];

	for(i = 0; i < strlen(string) + 1; i++)
	{
		enc_buf[i] = string[i] + key;
	}

	printf("[ENC] string: %s -> %s\n", string, enc_buf);
}

int main(int argc, char *argv[])
{
	if(argc <= 1)
	{
		printf("please give string to encrypt\n");
		exit(0);
	}

	crypt_enc(argv[1]);
}